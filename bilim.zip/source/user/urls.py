from django.urls import include, path
from rest_framework.routers import SimpleRouter

from user.views import (
    UserActivationStep1View,
    UserActivationStep2View,
    UserForgotPasswordView,
    UserForgotUsernameView,
    UserSetNewPasswordView,
    UserStatusViewSet,
    UserUpdateView,
    UserViewSet
)

router = SimpleRouter()
router.register(r'user', UserViewSet, 'user')

status_router = SimpleRouter()
status_router.register('', UserStatusViewSet, 'user-status')

app_name = 'user'
urlpatterns = [
    path('', include(router.urls)),
    path('profile/', include('user.profile.urls', namespace='profile')),
    path('status/<int:course_id>/', include(status_router.urls)),
    path('<int:pk>/edit/', UserUpdateView.as_view(), name='user-edit'),
    # Восстановление логина
    path('forgot/username/', UserForgotUsernameView.as_view(), name='user-forgot-username'),
    # Восстановление пароля
    path('forgot/password/', UserForgotPasswordView.as_view(), name='user-forgot-password'),
    path('forgot/set-password/', UserSetNewPasswordView.as_view(), name='user-set-new-password'),
    # Активация пользователя
    path('activation/step1/', UserActivationStep1View.as_view(), name='user-activation-step1'),
    path('activation/step2/', UserActivationStep2View.as_view(), name='user-activation-step2'),
]
