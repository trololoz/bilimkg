from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from user.models import User, ActivationCode


@admin.register(User)
class UserAdmin(UserAdmin):
    pass


@admin.register(ActivationCode)
class UserActivationCodeAdmin(admin.ModelAdmin):
    list_display = ['code', 'user']
