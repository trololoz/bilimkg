from celery.schedules import crontab

from core.celery import app


@app.task
def clean_inactive_users_task():
    from user.models import User
    User.delete_inactive_users()


@app.task
def clean_stale_activation_codes_task():
    from user.models import ActivationCode
    ActivationCode.delete_stale_activation_codes()


app.conf.beat_schedule.update({
    'clean.inactive.users.periodic.task': {
        'task': 'user.tasks.clean_inactive_users_task',
        'schedule': crontab(minute='5', hour='1'),
        'args': ()
    },
    'clean.stale.activation.codes.periodic.task': {
        'task': 'user.tasks.clean_stale_activation_codes_task',
        'schedule': crontab(minute='2', hour='1'),
    },
})
