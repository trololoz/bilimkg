import re


def digits_from_string(value: str):
    """
    Удаляет из строки все символы кроме цифр
    """
    return re.sub(r'\D', '', value)
