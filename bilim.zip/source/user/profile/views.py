from django.shortcuts import get_object_or_404
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from school.administrative.models import SchoolSubject
from school.administrative.serializers import SchoolCourseSerializer, SchoolSubjectSerializer
from school.models import School
from user.profile.models import Staff
from user.profile.serializers import StaffSerializer


class StaffViewSet(ModelViewSet):
    lookup_value_regex = '\d+'
    serializer_class = StaffSerializer
    queryset = Staff.objects.all()
    http_method_names = ('get', 'post', 'put', 'patch', 'head', 'options',)

    @action(methods=['get'], url_path='my-school-data', url_name='my-school-data', detail=False)
    def get_my_school_data(self, request, *args, **kwargs):
        print('get_school_data')
        print('request', request)
        print('args', args)
        print('kwargs', kwargs)

        school_id = request.GET.get('school_id')

        if not school_id:
            raise ValidationError('School ID not set')

        data = {}

        # получаем школу
        school = get_object_or_404(School, pk=int(school_id))

        # получаем запись профиля
        staff = get_object_or_404(Staff, user=request.user, school=school, is_active=True)
        data['staff'] = StaffSerializer(staff).data

        # получить предметы которые ведет преподаватель
        subjects = SchoolSubject.objects.filter(school=school, teachers=staff)
        print('subjects', subjects)
        print('subjects.query', subjects.query)
        data['subjects'] = SchoolSubjectSerializer(subjects, many=True).data

        # получить классы в которых классный руководитель
        courses = staff.master_courses.all()
        print('courses', courses)
        print('courses.query', courses.query)
        data['master_courses'] = SchoolCourseSerializer(courses, many=True).data

        return Response(data)
