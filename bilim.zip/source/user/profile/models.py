import architect
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _

from common.exceptions import DeleteNotAllowed
from ministry.models import StudyYear
# from school.administrative.models import Course
# from school.models import School
# from user.models import User
from user.profile.managers import PupilManager


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class Pupil(models.Model):
    """
    Ученик
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    school = models.ForeignKey('school.School', on_delete=models.CASCADE)
    course = models.ForeignKey('administrative.Course', on_delete=models.CASCADE)

    from_date = models.DateField(auto_now_add=True)
    till_date = models.DateField(null=True, blank=True)

    current = models.NullBooleanField(default=True)

    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)

    course_groups = models.ManyToManyField('administrative.CourseGroup', blank=True)

    objects = PupilManager.as_manager()

    # default_objects = models.Manager()

    class Meta:
        verbose_name = _('Ученик')
        verbose_name_plural = _('Ученики')

        unique_together = ('user', 'current',)

    def delete(self, using=None, keep_parents=False):
        raise DeleteNotAllowed


# class Relative(User):
#     """
#     Родственник
#     """
#
#     objects = ProfileManager.as_manager()
#
#     class Meta:
#         verbose_name = _('Родственик')
#         verbose_name_plural = _('Родственики')
#
#     def delete(self, using=None, keep_parents: bool = True):
#         """
#         По умолчанию сохраняем родительскую запись в таблице User
#         :param using:
#         :param keep_parents:
#         :return:
#         """
#         return super().delete(using, keep_parents)


# class Relationship(models.Model):
#     RELATION_MOTHER = 1
#     RELATION_FATHER = 2
#     RELATION_OTHER = 3
#
#     DEGREES = (
#         (RELATION_MOTHER, 'mother'),
#         (RELATION_FATHER, 'father'),
#         (RELATION_OTHER, 'other'),
#     )
#
#     pupil = models.ForeignKey(User, on_delete=models.CASCADE, related_name='pupils')
#     relative = models.ForeignKey(User, on_delete=models.CASCADE, related_name='relatives')
#     relation_degree = models.PositiveSmallIntegerField(
#         choices=DEGREES,
#         default=RELATION_MOTHER
#     )


class Staff(models.Model):
    """
    Персонал школы
    """

    ROLE_DIRECTOR = 1
    ROLE_HEAD = 2  # завуч
    ROLE_MANAGER = 3
    ROLE_PSYCHOLOGIST = 4
    ROLE_TEACHER = 5
    ROLE_ASSISTANT = 6  # лаборант
    ROLE_TRAINEE = 7  # практикант

    ROLES = (
        (ROLE_DIRECTOR, 'director'),
        (ROLE_HEAD, 'head'),
        (ROLE_MANAGER, 'manager'),
        (ROLE_PSYCHOLOGIST, 'psychologist'),
        (ROLE_TEACHER, 'teacher'),
        (ROLE_ASSISTANT, 'assistant'),
        (ROLE_TRAINEE, 'trainee'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)

    school = models.ForeignKey('school.School', on_delete=models.CASCADE)

    position = models.CharField(max_length=128)  # описательное свойство, нап.: Учитель математики в младших классах
    role = models.PositiveSmallIntegerField(choices=ROLES, default=ROLE_TEACHER)

    from_date = models.DateField(null=True, blank=True)
    till_date = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name = _('Персонал школы')
        verbose_name_plural = _('Персонал школы')

    def __str__(self):
        return str(self.user)

    def delete(self, using=None, keep_parents: bool = True):
        """
        По умолчанию сохраняем родительскую запись в таблице User
        :param using:
        :param keep_parents:
        :return:
        """
        return super().delete(using, keep_parents)


class Official(models.Model):
    """
    Персонал министерства
    """

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    # objects = ProfileManager.as_manager()

    class Meta:
        verbose_name = _('Официальное лицо')
        verbose_name_plural = _('Официальные лица')

    def delete(self, using=None, keep_parents: bool = True):
        """
        По умолчанию сохраняем родительскую запись в таблице User
        :param using:
        :param keep_parents:
        :return:
        """
        return super().delete(using, keep_parents)
