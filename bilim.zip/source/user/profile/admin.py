from django.contrib import admin

from user.profile.models import Official, Pupil, Staff


@admin.register(Official)
class OfficialAdmin(admin.ModelAdmin):
    pass


@admin.register(Pupil)
class PupilAdmin(admin.ModelAdmin):
    pass


# @admin.register(Relative)
# class RelativeAdmin(admin.ModelAdmin):
#     pass


@admin.register(Staff)
class StaffAdmin(admin.ModelAdmin):
    list_display = ['user', 'school', 'position', 'role']
