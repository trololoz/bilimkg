from rest_framework import serializers

from user.profile.models import Pupil, Staff
from user.serializers import UserLiteSerializer


class PupilSerializer(serializers.ModelSerializer):
    user = UserLiteSerializer(read_only=True)

    class Meta:
        model = Pupil
        fields = ('pk', 'user', 'school', 'course', 'from_date', 'till_date', 'current', 'course_groups')


class StaffSerializer(serializers.ModelSerializer):
    user = UserLiteSerializer(read_only=True)

    class Meta:
        model = Staff
        fields = ('pk', 'user', 'school', 'position', 'role', 'from_date', 'till_date')
