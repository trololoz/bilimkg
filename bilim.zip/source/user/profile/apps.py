from django.apps import AppConfig
from django.db.models.signals import post_migrate

from common.utils.partitioning import create_partitions


class UserProfileConfig(AppConfig):
    name = 'user.profile'
    # label = 'user.profile'

    def ready(self):
        super().ready()
        # Hook up Architect to the post migrations signal
        post_migrate.connect(create_partitions, sender=self)
        # if settings.DJANGO_ENV == 'DEVELOPING':
        #     post_migrate.connect(create_fixture, sender=self)
