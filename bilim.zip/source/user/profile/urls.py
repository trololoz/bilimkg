from django.urls import include, path
from rest_framework.routers import SimpleRouter

from user.profile.views import StaffViewSet

router = SimpleRouter()
router.register('staff', StaffViewSet)

app_name = 'user.profile'
urlpatterns = [
    path('', include(router.urls)),
]
