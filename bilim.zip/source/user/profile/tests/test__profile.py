from common.exceptions import BulkDeleteNotAllowed, DeleteNotAllowed
from common.tests import CommonTestCase, create_pupil
from user.models import User
from user.profile.models import Pupil, Staff


class DeleteProfileTest(CommonTestCase):

    def setUp(self):
        super().setUp()

        for i in range(10):
            create_pupil()

    def test__single_pupil_delete(self):
        p_cnt = Pupil.objects.count()
        u_cnt = User.objects.count()

        with self.assertRaises(DeleteNotAllowed):
            Pupil.objects.order_by('?').first().delete()

        self.assertEqual(p_cnt, Pupil.objects.count())
        self.assertEqual(u_cnt, User.objects.count())

    def test__bulk_pupil_delete(self):

        p_cnt = Pupil.objects.count()
        u_cnt = User.objects.count()

        with self.assertRaises(BulkDeleteNotAllowed):
            Pupil.objects.all().delete()

        self.assertEqual(p_cnt, Pupil.objects.count())
        self.assertEqual(u_cnt, User.objects.count())

    # def test__single_staff_delete(self):
    #     s_cnt = Staff.objects.count()
    #     u_cnt = User.objects.count()
    #
    #     with self.assertRaises(DeleteNotAllowed):
    #         Staff.objects.order_by('?').first().delete()
    #
    #     self.assertEqual(s_cnt, Staff.objects.count())
    #     self.assertEqual(u_cnt, User.objects.count())

    def test__bulk_staff_delete(self):

        s_cnt = Staff.objects.count()
        u_cnt = User.objects.count()

        # TODO?
        # with self.assertRaises(BulkDeleteNotAllowed):
        #     Staff.objects.all().delete()

        self.assertEqual(s_cnt, Staff.objects.count())
        self.assertEqual(u_cnt, User.objects.count())
