from django.contrib.auth.models import UserManager
from django.db import models

from common.exceptions import BulkDeleteNotAllowed
from ministry.models import StudyYear


class ProfileManager(models.QuerySet, UserManager):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def delete(self):
        raise BulkDeleteNotAllowed


class PupilManager(models.QuerySet):
    """
    manager для учеников
    """

    def get_queryset(self):
        """
        по умолчанию фильтруем все записи по текущему учебному году
        и получаем только активный профиль
        """
        return super().get_queryset().filter(current=True, study_year_id=StudyYear.get_current_id())

    def delete(self):
        raise BulkDeleteNotAllowed
