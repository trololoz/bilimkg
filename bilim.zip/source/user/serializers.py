from django.contrib.auth.password_validation import validate_password
from django.db import IntegrityError, transaction
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers

from user.models import User
from user.utils import digits_from_string


class UserPasswordSerializerMixin:
    def validate_password(self, value):
        validate_password(value)
        return value


class BaseUserSerializer(serializers.ModelSerializer):
    thumb = serializers.ImageField(source='x50', read_only=True)

    class Meta:
        model = User
        fields = (
            'pk', 'first_name', 'last_name', 'patronymic', 'sex', 'thumb'
        )
        extra_kwargs = {
            'photo': {
                'write_only': True,
            },
        }


class UserLiteSerializer(BaseUserSerializer):
    class Meta(BaseUserSerializer.Meta):
        pass


class UserSerializer(serializers.ModelSerializer):
    thumb = serializers.ImageField(source='x50', read_only=True)

    class Meta:
        model = User
        fields = (
            'pk', 'first_name', 'last_name', 'patronymic', 'email', 'sex', 'phone', 'additional_phone', 'is_active',
            'photo', 'thumb', 'roles', 'roles_data', 'is_superuser'
        )
        extra_kwargs = {
            'photo': {
                'write_only': True,
            },

        }

    def validate_first_name(self, value):
        return value.title()

    def validate_last_name(self, value):
        return value.title()

    def validate_patronymic(self, value):
        return value.title()

    def validate_additional_phone(self, value):
        return digits_from_string(value)


class UserCreateSerializer(UserSerializer):
    thumb = serializers.ImageField(source='x50', read_only=True)

    class Meta:
        model = User
        fields = (
            'pk', 'first_name', 'last_name', 'patronymic', 'email', 'sex', 'phone', 'additional_phone', 'photo',
            'thumb'
        )
        extra_kwargs = {
            'photo': {
                'write_only': True,
            },
        }

    def create(self, data):
        """
        Создание пользователя с уникальным username
        """
        data['username'] = User.generate_username(data['first_name'], data['last_name'])
        user = User(**data)

        cnt = User.objects.filter(
            first_name=data['first_name'],
            last_name=data['last_name']
        ).count()

        while not user.id:
            try:
                with transaction.atomic():
                    user.save()
            except IntegrityError:
                cnt += 1
                user.username = '{}-{}'.format(data['username'], cnt)
        return user


class UserUpdateSerializer(serializers.ModelSerializer, UserPasswordSerializerMixin):
    class Meta:
        model = User
        fields = ['pk', 'username', 'password', 'email', 'phone']
        extra_kwargs = {
            "password": {"write_only": True},
        }

    def update(self, instance, validated_data):
        password = validated_data.pop('password')
        instance.set_password(password)
        return super().update(instance, validated_data)


class UserActivationStep1Serializer(serializers.ModelSerializer):
    """Принимает ФИО и код активации пользователя (первый этап)."""
    code = serializers.IntegerField()
    user = None

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'code')

    def validate(self, data):
        users = User.objects.filter(first_name=data['first_name'], last_name=data['last_name'])
        if not users.exists():
            raise serializers.ValidationError(_('Пользователь с указанными Именем и Фамилией не найден. '
                                                'Проверьте правильность введенных данных.'))
        try:
            # TODO: возможно стоит рассмотреть ситуацию, когда код отсутствует
            self.user = users.only('pk', 'is_active').get(activation_code__code=data['code'])
        except User.DoesNotExist:
            raise serializers.ValidationError({'code': _('Ошибка проверки кода активации. Убедитесь в правильности '
                                                         'ввода данных.')})
        if self.user.is_active:
            raise serializers.ValidationError(_('Пользователь уже активирован, войдите в систему используя '
                                                'логин и пароль.'))
        return data


class UserActivationStep2Serializer(UserPasswordSerializerMixin, serializers.ModelSerializer):
    """Принимает личные данные пользователя (второй этап)."""
    user_id = serializers.IntegerField()
    code = serializers.IntegerField()
    password_confirmation = serializers.CharField(style={'input_type': 'password'})

    class Meta:
        model = User
        fields = ('user_id', 'code', 'username', 'password', 'password_confirmation', 'phone', 'email')

    def validate_password_confirmation(self, value):
        if self.initial_data['password'] != self.initial_data['password_confirmation']:
            raise serializers.ValidationError(_('Пароли не совпадают.'))
        return value


class UserStatusSerializer(serializers.ModelSerializer):
    """Сериализирует учеников и их родственников для отображения списка
    кодов активации.
    """
    code = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ('pk', 'first_name', 'last_name', 'patronymic', 'code', 'is_active')

    def get_code(self, obj):
        if hasattr(obj, 'activation_code'):
            return obj.activation_code.code


class UserForgotUsernameSerializer(serializers.Serializer):
    """Сериализирует данные в том случае, когда пользователь забыл свой логин."""
    email = serializers.EmailField(required=False)
    phone = serializers.CharField(required=False)
    birth_date = serializers.DateField()

    class Meta:
        fields = ('email', 'phone', 'birth_date')

    def validate(self, data):
        if data.get('email') is None and data.get('phone') is None:
            raise serializers.ValidationError(_('Поле email либо phone обязательно.'))
        return data


class _BaseUsernameValidationSerializer(serializers.Serializer):
    username = serializers.CharField()

    class Meta:
        abstract = True
        fields = ('username',)

    def validate_username(self, value):
        if not User.objects.filter(username=value).exists():
            raise serializers.ValidationError(_('Пользователь с таким логином не найден.'))
        return value


class UserForgotPasswordSerializer(_BaseUsernameValidationSerializer):
    """Сериализирует данные в том случае, когда пользователь забыл свой пароль."""
    class Meta(_BaseUsernameValidationSerializer.Meta):
        pass


class UserSetNewPasswordSerializer(UserPasswordSerializerMixin, _BaseUsernameValidationSerializer):
    """Сериализирует данные для того, чтобы пользователь мог ввести новый пароль."""
    code = serializers.IntegerField()
    password = serializers.CharField()

    class Meta(_BaseUsernameValidationSerializer.Meta):
        fields = _BaseUsernameValidationSerializer.Meta.fields + ('code', 'password')
