from datetime import timedelta
from django.conf import settings
from django.contrib.auth import login
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from rest_framework import views, viewsets
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.generics import GenericAPIView, RetrieveUpdateAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from school.administrative.models import Course
from user.models import PasswordVerificationCode, User
from user.permissions import IsSchoolStaff, IsSelfUser
from user.profile.models import Staff
from user.serializers import (
    UserActivationStep1Serializer, UserActivationStep2Serializer, UserCreateSerializer, UserForgotPasswordSerializer,
    UserForgotUsernameSerializer, UserSerializer, UserSetNewPasswordSerializer, UserStatusSerializer,
    UserUpdateSerializer
)
from user.tasks import clean_stale_activation_codes_task


class UserViewSet(viewsets.ModelViewSet):
    serializer_class = UserSerializer
    queryset = User.objects.all()
    http_method_names = ('get', 'post', 'put', 'patch', 'head', 'options')

    def get_permissions(self):
        if self.action in ('update', 'partial_update'):
            self.permission_classes = [IsSelfUser]
        return super().get_permissions()

    def get_serializer_class(self):
        if self.action == 'create':
            return UserCreateSerializer
        else:
            return super().get_serializer_class()

    def get_object(self):
        if self.kwargs.get('pk', None) == 'me':
            self.kwargs['pk'] = self.request.user.pk
        return super().get_object()


class UserActivationStep1View(GenericAPIView):
    """
    Проверяет возможность активации и, если данные верны, возвращает ID пользователя.
    """
    serializer_class = UserActivationStep1Serializer
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'user_id': serializer.user.pk})


class UserActivationStep2View(GenericAPIView):
    """
    Активирует пользователя, логинит в систему и обновляет его личные данные.
    """
    serializer_class = UserActivationStep2Serializer
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = get_object_or_404(User, pk=serializer.data['user_id'], activation_code__code=serializer.data['code'])
        user.username = serializer.data['username']
        user.is_active = True
        user.phone = serializer.data['phone']
        user.email = serializer.data.get('email')
        user.set_password(serializer.data['password'])
        user.save()
        login(request, user)
        clean_stale_activation_codes_task.apply_async(
            eta=timezone.now() + timedelta(days=settings.USER_ACTIVATION_CODES_PURGE_PERIOD)
        )
        return Response(_("Пользователь успешно активирован и залогинен в систему."))


class UserStatusViewSet(viewsets.ModelViewSet):
    """Отображает список кодов активации учеников и их родителей."""
    http_method_names = ('get', 'head', 'options')
    serializer_class = UserStatusSerializer
    permission_classes = (IsAuthenticated, IsSchoolStaff)
    queryset = User.objects.all()

    def _is_school_head(self, school):
        """Является ли пользователь завучем?"""
        for role_data in self.request.user.roles_data['school_staff_of']:
            if role_data['role'] == Staff.ROLE_HEAD and role_data['school'] == school.pk:
                return True
        return False

    def _is_form_master(self, course):
        """Является ли пользователь классным руководителем?"""
        if course.form_master is not None:
            return self.request.user.pk == course.form_master.user.pk
        return False

    def _get_course_pupils(self, course):
        """Фильтрует список кодов, оставляя только учеников класса."""
        return self.queryset.filter(pupil__course=course)

    def _get_course_pupil_relatives(self, pupils):
        """
        Фильтрует список кодов, оставляя только родственников
        учеников.
        """
        pupil_pks = filter(lambda x: x is not None, pupils.values_list('pupil', flat=True))
        return self.queryset.filter(pupil__user__relatives__pk__in=pupil_pks)

    def list(self, request, *args, **kwargs):
        course = get_object_or_404(Course, pk=kwargs['course_id'])
        if self._is_school_head(course.school) or self._is_form_master(course):
            pupils = self._get_course_pupils(course)
            relatives = self._get_course_pupil_relatives(pupils)
            serializer = self.serializer_class(pupils | relatives, many=True)
            return Response(serializer.data)
        raise PermissionDenied


class UserUpdateView(RetrieveUpdateAPIView):
    serializer_class = UserUpdateSerializer
    queryset = User
    permission_classes = (IsSelfUser,)


class UserForgotUsernameView(views.APIView):
    """Отправляет на email или телефон сообщение с логином пользователя."""
    serializer_class = UserForgotUsernameSerializer
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        phone = serializer.data.get('phone')
        birth_date = serializer.data['birth_date']
        _users = User.objects.filter(birth_date=birth_date).values_list('username', flat=True)
        has_email = email is not None and _users.filter(email=email).exists()
        has_phone = phone is not None and _users.filter(phone=phone).exists()
        if has_email:
            self._send_email(email, _users.get(email=email))
            return Response(_(f'Логин пользователя отправлен на {email}.'))
        elif has_phone:
            self._send_sms(phone, _users.get(phone=phone))
            return Response(_(f'СМС с логином пользователя отправлен на {phone}.'))
        else:
            raise ValidationError(_('Пользователь с такими данными не найден.'))

    @staticmethod
    def _send_email(email, username):
        # TODO отправить логин пользователя на его эл. почту
        pass

    @staticmethod
    def _send_sms(phone, username):
        # TODO отправить СМС с логином пользователя на его телефон
        pass


class UserForgotPasswordView(views.APIView):
    """Отправляет на email или телефон сообщение с проверочным кодом (6-8 цифр)."""
    serializer_class = UserForgotPasswordSerializer
    permission_classes = (AllowAny,)

    def _send_verification_code(self, user):
        """Отправляет на email или телефон проверочный код."""
        new_code = PasswordVerificationCode.objects.create(user=user)
        if user.email:
            self._send_email(user.email, new_code.code)
            return Response(_('На Ваш email был выслан проверочный код.'))
        elif user.phone:
            self._send_sms(user.phone, new_code.code)
            return Response(_('На Ваш номер был выслан СМС с проверочным кодом.'))
        else:
            raise ValidationError(_('Вы не можете восстановить доступ онлайн и для получения кода активации необходимо '
                                    'обратиться к классному руководителю или завучу.'))

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = User.objects.get(username=serializer.data['username'])
        return self._send_verification_code(user)

    @staticmethod
    def _send_email(email, activation_code):
        # TODO отправить проверочный код пользователя на его эл. почту
        pass

    @staticmethod
    def _send_sms(phone, activation_code):
        # TODO отправить СМС с проверочным кодом пользователя на его телефон
        pass


class UserSetNewPasswordView(views.APIView):
    serializer_class = UserSetNewPasswordSerializer
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = get_object_or_404(User, username=serializer.data['username'])
        self._validate_code(user, serializer.data['code'])
        user.set_password(serializer.data['password'])
        user.save(update_fields=['password'])
        self._deactivate_code(user)
        return Response(_('Пароль изменен.'))

    @staticmethod
    def _validate_code(user, code):
        """Проверяет правильность проверочного кода."""
        try:
            pwd_code = PasswordVerificationCode.objects.only('code').get(user=user, is_active=True)
        except PasswordVerificationCode.DoesNotExist:
            pass
        else:
            if pwd_code.code == code:
                return
        raise ValidationError(_('Неверный проверочный код.'))

    @staticmethod
    def _deactivate_code(user):
        """Делает проверочный код неактивным."""
        pwd_code = get_object_or_404(PasswordVerificationCode, user=user, is_active=True)
        pwd_code.is_active = False
        pwd_code.save(update_fields=['is_active'])
