from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.cache import cache
from django.core.validators import RegexValidator
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from django.utils.functional import cached_property
from django.utils.text import slugify
from django.utils.translation import ugettext_lazy as _
from imagekit.models import ImageSpecField
from imagekit.processors import Adjust, ResizeToFit, SmartResize

from common.mixins import RandomCodeGeneratorMixin
from common.models import BaseTimestampedModel
from common.validators import KGMobilePhoneValidator, PinCodeValidator
from ministry.models import StudyYear
from user.profile.models import Pupil, Staff


class User(AbstractUser):
    SEX_MALE = 1
    SEX_FEMALE = 2
    SEX = (
        (SEX_MALE, 'male',),
        (SEX_FEMALE, 'female',),
    )

    ROLE_OFFICIAL = 'official'
    ROLE_SCHOOL_STAFF = 'school_staff'
    ROLE_RELATIVE = 'relative'
    ROLE_PUPIL = 'pupil'

    ROLES = {
        ROLE_OFFICIAL,
        ROLE_SCHOOL_STAFF,
        ROLE_RELATIVE,
        ROLE_PUPIL,
    }

    is_active = models.BooleanField(
        verbose_name=_('Активный'),
        default=False,
        help_text=_(
            'Указывает, должен ли этот пользователь считаться активным. '
            'Снимите этот флажок, а не удаляйте учетные записи.'
        ),
    )

    first_name = models.CharField(verbose_name=_('Имя'), max_length=50)
    last_name = models.CharField(verbose_name=_('Фамилия'), max_length=150)
    patronymic = models.CharField(_('Отчество'), max_length=150, blank=True, null=True)
    email = models.EmailField(_('Адрес электронной почты'), unique=True, blank=True, null=True)
    password = models.CharField(verbose_name=_('Пароль'), max_length=128, blank=True, null=True)
    pin_code = models.PositiveSmallIntegerField(verbose_name=_('Пин код'), blank=True, null=True,
                                                validators=[PinCodeValidator()])
    sex = models.PositiveSmallIntegerField(choices=SEX, blank=True, null=True)

    phone = models.CharField(max_length=9, verbose_name=_('Телефон'), blank=True, null=True,
                             validators=[KGMobilePhoneValidator()])
    additional_phone = models.CharField(max_length=12, verbose_name=_('Доп. телефон'), blank=True, null=True)
    birth_date = models.DateField(_('Дата рождения'), null=True)

    photo = models.ImageField(blank=True, null=True)

    relatives = models.ManyToManyField('self', blank=True)

    class Meta:
        indexes = [
            models.Index(fields=['phone'], name='phone_idx')
        ]
        verbose_name = _('Пользователь')
        verbose_name_plural = _('Пользователи')

    def __str__(self):
        return '{} {}'.format(self.first_name, self.last_name)

    @cached_property
    def pupil(self):
        try:
            return self.pupil_set.get(current=True)
        except Pupil.DoesNotExist:
            return None

    @staticmethod
    def generate_username(first_name, last_name):
        return slugify('{}-{}'.format(first_name, last_name), allow_unicode=True)

    @classmethod
    def delete_inactive_users(cls):
        """Удаляет пользователей, которые не активировали аккаунт в течение N дней."""
        cls.objects.filter(
            activation_code__add_date__lt=timezone.now() - timedelta(days=settings.USER_ACTIVATION_PERIOD),
            is_active=False
        ).delete()

    @cached_property
    def roles_data(self):
        key = settings.USER_ROLES_CACHE_KEY.format(self.id)

        data = cache.get(key, {})
        if data:
            return data

            # if self.is_superuser:
            #     data['is_superuser'] = True

        if hasattr(self, 'official'):
            data['is_official'] = True

        try:
            pupil = self.pupil_set.only('pk', 'school_id', 'course_id').get(current=True)
        except Pupil.DoesNotExist:
            pass
        else:
            data['is_pupil'] = True
            data['pupil'] = [{
                'pk': pupil.pk,
                'school': pupil.school_id,
                'course': pupil.course_id,
            }]

        if self.relatives.exists():
            data['is_relative'] = True
            # @todo добавить проверку чтобы тут выводились только ученики,
            # те только те кто имеет активную запись в таблице Pupil
            data['relative_of'] = [{
                'pupil': r.pk,
            } for r in self.relatives.filter(pupil__isnull=False)]

        if self.staff_set.exists():
            data['is_school_staff'] = True
            data['school_staff_of'] = [{
                'school_id': s.school_id,
                'position': s.position,
                'role': s.role,
                'name': s.school.name,
            } for s in self.staff_set
                .filter(is_active=True)
                # .only('school_id', 'role', 'position', 'school')
                .prefetch_related('school')]

            # if Course.objects.filter(form_master__in=self.staff_set.filter(is_active=True)).exists():
            #     data['master_of'] = [{
            #         'parallel': c.parallel,
            #         'index': c.index,
            #         'name': c.name,
            #     } for c in Course.objects.filter(
            #         form_master__in=self.staff_set.filter(is_active=True),
            #         study_year=StudyYear.get_current()
            #     )]

        cache.set(key, data, None)

        return data

    @cached_property
    def roles(self):
        roles = set()
        for k, v in self.roles_data.items():
            # if k == 'is_superuser' and v:
            #     roles.add(self.ROLE_SUPERUSER)
            if k == 'is_official' and v:
                roles.add(self.ROLE_OFFICIAL)
            elif k == 'is_school_staff' and v:
                roles.add(self.ROLE_SCHOOL_STAFF)
            elif k == 'is_relative' and v:
                roles.add(self.ROLE_RELATIVE)
            elif k == 'is_pupil' and v:
                roles.add(self.ROLE_PUPIL)

        return roles

    x50 = ImageSpecField([
        Adjust(contrast=1.2, sharpness=1.1),
        ResizeToFit(50, 50, False),
    ],
        source='photo',
        options={
            'quality': 90,
            'progressive': True,
        },
    )

    crop50 = ImageSpecField([
        Adjust(contrast=1.2, sharpness=1.1),
        SmartResize(50, 50),
    ],
        source='photo',
        options={
            'quality': 90,
            'progressive': True,
        }
    )

    x100 = ImageSpecField([
        Adjust(contrast=1.2, sharpness=1.1),
        ResizeToFit(100, 100, False),
    ],
        source='photo',
        options={
            'quality': 90,
            'progressive': True,
        },
    )

    crop100 = ImageSpecField([
        Adjust(contrast=1.2, sharpness=1.1),
        SmartResize(100, 100),
    ],
        source='photo',
        options={
            'quality': 90,
            'progressive': True,
        }
    )


class ActivationCode(models.Model, RandomCodeGeneratorMixin):
    """Активационный код, привязываемый к пользователю."""
    user = models.OneToOneField(User, related_name='activation_code', on_delete=models.CASCADE)
    code = models.IntegerField(verbose_name=_('Код'), validators=[RegexValidator(r'^\d{6}$')])
    add_date = models.DateField(_('Дата создания'), auto_now_add=True, db_index=True)

    # RandomCodeGeneratorMixin
    code_generation_range = (100000, 999999)

    class Meta:
        verbose_name = _('Код активации')
        verbose_name_plural = _('Коды активации')

    def save(self, *args, **kwargs):
        if self.pk is None:
            self.code = self._generate_code()
        super().save(*args, **kwargs)

    @classmethod
    def delete_stale_activation_codes(cls):
        """Удаляет активационные коды уже активированных пользователей."""
        t = timezone.now() - timedelta(days=settings.USER_ACTIVATION_CODES_PURGE_PERIOD)
        cls.objects.filter(user__is_active=True, add_date__lt=t).delete()


@receiver(post_save, sender=User)
def create_activation_code(sender, instance, created, **kwargs):
    """Создает новый активационный код для созданного пользователя."""
    if created:
        ActivationCode.objects.create(user=instance)


class PasswordVerificationCode(models.Model, RandomCodeGeneratorMixin):
    """Проверочный код, необходимый для восстановления пароля."""
    user = models.ForeignKey('User', related_name='pwd_verification_codes', on_delete=models.CASCADE)
    code = models.IntegerField(_('Код'), validators=[RegexValidator(r'^\d{6,8}$')])
    is_active = models.BooleanField(_('Активный'), default=True)
    add_date = models.DateField(_('Дата создания'), auto_now_add=True, db_index=True)

    # RandomCodeGeneratorMixin
    code_generation_range = (100000, 99999999)

    class Meta:
        # @todo этот индекс нужен? именно составной
        unique_together = ['user', 'code']
        verbose_name = _('Проверочный код')
        verbose_name_plural = _('Проверочные коды')

    def save(self, *args, **kwargs):
        if self.pk is None:
            self.code = self._generate_code()
        super().save(*args, **kwargs)


@receiver(post_save, sender=PasswordVerificationCode)
def deactivate_old_verification_codes(sender, instance, created, **kwargs):
    """
    Делает все предыдущие коды данного пользователя неактивными при генерации нового кода.
    """
    if created:
        PasswordVerificationCode.objects.filter(user=instance.user).exclude(pk=instance.pk).update(is_active=False)
