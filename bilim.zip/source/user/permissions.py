from django.db import OperationalError, ProgrammingError
from rest_framework.permissions import BasePermission

from user.models import User


class IsSelfUser(BasePermission):
    def has_permission(self, request, view):
        print('IsSelfUser:view.kwargs', view.kwargs)
        # if 'pk' in view.kwargs:
        #     return request.user.id == int(view.kwargs['pk'])


class IsOfficial(BasePermission):
    """Пользователь является работником министерства"""
    def has_permission(self, request, view):
        if hasattr(request.user, 'roles'):
            return User.ROLE_OFFICIAL in request.user.roles
        return False


class IsSchoolStaff(BasePermission):
    """Пользователь является работником школы"""
    def has_permission(self, request, view):
        if hasattr(request.user, 'roles'):
            return User.ROLE_SCHOOL_STAFF in request.user.roles
        return False


class IsRelative(BasePermission):
    """Пользователь является родственником ученика"""
    def has_permission(self, request, view):
        if hasattr(request.user, 'roles'):
            return User.ROLE_RELATIVE in request.user.roles
        return False


class IsPupil(BasePermission):
    """Пользователь является учеником"""
    def has_permission(self, request, view):
        if hasattr(request.user, 'roles'):
            return User.ROLE_PUPIL in request.user.roles
        return False


def make_profile_permissions(required_groups_for_actions=None, allow_by_default=False):
    """

    A factory method that produces GenericGroupPermission classes.

        note: object permissions can be specified at the view level,
              see GenericGroupPermission's has_object_permission method for details.


    :param required_groups_for_actions:
        A dictionary of tuples where keys are actions
        and values are groups that are allowed to perform given actions.
        Values can have nested tuples representing that multiple roles may be required.
    :param allow_by_default:
        A boolean that specifies default behavior
        if performed action is not specified in required_groups_for_actions
    :return:
        GenericGroupPermission class (not an instance of it)
    """
    # try-except block is a workaround required to make migrations work:
    # during migrations, this piece of code tries to execute
    # and crashes with OperationalError: table does not exist
    try:
        if required_groups_for_actions is None:
            required_groups_for_actions = {}

        class GenericProfilePermission(BasePermission):
            action_groups_map = {}

            def __init__(self):
                _available_groups = User.ROLES
                _mentioned_groups = set()
                _action_groups_map = {}

                for actions, groups in required_groups_for_actions.items():
                    # if not groups:
                    #     continue
                    for action in actions:
                        _action_groups_map[action] = list()
                        for group_unit in groups:
                            if isinstance(group_unit, str):
                                group_unit = (group_unit,)
                            _mentioned_groups |= set(group_unit)
                            _action_groups_map[action].append(group_unit)

                if not _mentioned_groups.issubset(_available_groups):
                    raise ValueError('Permission class mentions invalid group names: {groups}'
                                     .format(groups=_mentioned_groups.difference(_available_groups)))

                self.action_groups_map = _action_groups_map
                self.default = allow_by_default

            def has_permission(self, request, view):
                if not hasattr(view, 'action'):
                    return True

                try:
                    user_roles = set(request.user.roles)
                except AttributeError:
                    return False

                if self.action_groups_map.get(view.action, None) is None:
                    return self.default

                for required_group_unit in self.action_groups_map[view.action]:
                    if set(required_group_unit).issubset(user_roles):
                        return True

                return False

            def has_object_permission(self, request, view, obj):
                if not hasattr(view, 'has_object_permission'):
                    return self.default

                if not callable(view.has_object_permission):
                    raise TypeError('has_object_permission on view {view_name} must be a callable'
                                    .format(view_name=view.__class__.__name__))

                try:
                    allow = view.has_object_permission(request, obj)
                    if type(allow) is not bool:
                        raise TypeError('has_object_permission on view {view_name} must return a boolean'
                                        'request and object'
                                        .format(view_name=view.__class__.__name__))
                    return allow

                except TypeError:
                    raise TypeError('has_object_permission on view {view_name} must take 2 arguments:'
                                    'request and object'
                                    .format(view_name=view.__class__.__name__))

        return GenericProfilePermission

    except (OperationalError, ProgrammingError):
        pass
