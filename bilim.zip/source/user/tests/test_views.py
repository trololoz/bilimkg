from datetime import date
from django.http import Http404
from rest_framework.permissions import IsAuthenticated
from rest_framework.test import APIRequestFactory
from common.tests.utils import create_user
from common.tests.views import ViewSetTestCase
from user.models import PasswordVerificationCode
from user.permissions import IsSelfUser
from user.serializers import UserSerializer, UserCreateSerializer
from user.views import (
    UserViewSet, UserActivationStep1View, UserActivationStep2View, UserForgotUsernameView, UserForgotPasswordView,
    UserSetNewPasswordView
)


class UserViewSetTest(ViewSetTestCase):
    view_class = UserViewSet
    view_kwargs = {
        'action': 'create',
        'kwargs': {'pk': 'me'}
    }

    def test_get_permissions(self):
        self.assertIsInstance(self.view.get_permissions()[0], IsAuthenticated)
        self.view_kwargs['action'] = 'update'
        self.assertIsInstance(self.view.get_permissions()[0], IsSelfUser)
        self.view_kwargs['action'] = 'partial_update'
        self.assertIsInstance(self.view.get_permissions()[0], IsSelfUser)

    def test_get_serializer_class(self):
        self.view_kwargs['action'] = 'create'
        self.assertIs(self.view.get_serializer_class(), UserCreateSerializer)
        self.view_kwargs['action'] = 'update'
        self.assertIs(self.view.get_serializer_class(), UserSerializer)

    def test_get_object(self):
        self.assertEqual(self.view.get_object(), self.request.user)
        self.view_kwargs['kwargs']['pk'] = '123'
        self.assertRaises404(self.view.get_object)


class UserActivationStep1ViewTest(ViewSetTestCase):
    view_class = UserActivationStep1View
    view_kwargs = {
        'format_kwarg': 'json'
    }

    def test_post(self):
        user = create_user(is_active=False)
        self.request.data = {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'code': user.activation_code.code
        }
        self.assertResponseIsOk(self.view.post(self.request))


class UserActivationStep2ViewTest(ViewSetTestCase):
    view_class = UserActivationStep2View
    view_kwargs = {
        'format_kwarg': 'json'
    }

    def test_post(self):
        # Несуществующий пользователь
        user = create_user(is_active=False)
        self.request.data = {
            'user_id': 0,
            'code': user.activation_code.code,
            'username': 'test-user-87654',
            'password': 'abcdefg123',
            'password_confirmation': 'abcdefg123',
            'phone': '559886655',
            'email': 'test-987654@email.ru'
        }
        self.assertRaises404(self.view.post, self.request)
        # Правильные данные
        self.request.data = {
            'user_id': user.pk,
            'code': user.activation_code.code,
            'username': 'test-user-87654',
            'password': 'abcdefg123',
            'password_confirmation': 'abcdefg123',
            'phone': '559886655',
            'email': 'test-987654@email.ru'
        }
        self.assertResponseIsOk(self.view.post(self.request))


class UserForgotUsernameViewTest(ViewSetTestCase):
    view_class = UserForgotUsernameView

    def test_post(self):
        # Неверные данные (несуществующий пользователь)
        self.request.data = {
            'email': 'test-78483@email.ru',
            'birth_date': date(1989, 12, 1)
        }
        self.assertRaisesValidationError(self.view.post, self.request)
        # Правильные данные (используется эл. почта)
        self.request.data = {
            'email': self.user.email,
            'birth_date': self.user.birth_date
        }
        self.assertResponseIsOk(self.view.post(self.request))
        # Правильные данные (используется телефон)
        self.user.phone = '559887766'
        self.user.save(update_fields=['phone'])
        self.request.data = {
            'phone': self.user.phone,
            'birth_date': self.user.birth_date
        }
        self.assertResponseIsOk(self.view.post(self.request))


class UserForgotPasswordViewTest(ViewSetTestCase):
    view_class = UserForgotPasswordView

    def test_post(self):
        # Несуществующий пользователь
        self.request.data = {
            'username': 'non-existent-user'
        }
        self.assertRaisesValidationError(self.view.post, self.request)
        # Правильные данные
        self.request.data = {
            'username': self.user.username
        }
        self.assertResponseIsOk(self.view.post(self.request))


class UserSetNewPasswordViewTest(ViewSetTestCase):
    view_class = UserSetNewPasswordView

    def setUp(self):
        super().setUp()
        self.verification_code = PasswordVerificationCode.objects.create(user=self.user)

    def test_post(self):
        # Несуществующий пользователь
        self.request.data = {
            'username': 'non-existent-user',
            'code': '123456',
            'password': 'abcdefgh'
        }
        self.assertRaisesValidationError(self.view.post, self.request)
        # Правильные данные
        self.request.data = {
            'username': self.user.username,
            'code': self.verification_code.code,
            'password': 'xyzxyzxyz123'
        }
        self.assertResponseIsOk(self.view.post(self.request))
