from common.tests.serializers import SerializerTestCase
from common.tests.utils import create_user
from user import serializers


class UserActivationStep1SerializerTest(SerializerTestCase):
    serializer_class = serializers.UserActivationStep1Serializer

    def setUp(self):
        super().setUp()
        self.inactive_user = create_user(is_active=False)

    def test_validator(self):
        self.assertInvalid()
        self.assertValid(initial_data={
            'first_name': self.inactive_user.first_name,
            'last_name': self.inactive_user.last_name,
            'code': self.inactive_user.activation_code.code
        })


class UserActivationStep2SerializerTest(SerializerTestCase):
    serializer_class = serializers.UserActivationStep2Serializer

    def test_password_validator(self):
        self.assertInvalid('password', '')
        self.assertInvalid('password', 'abc')
        self.assertValid('password', 'abcdefg123')

    def test_password_confirmation_validator(self):
        self.assertInvalid('password_confirmation', 'abcdefgh')
        self.assertInvalid('password_confirmation', 'abcdefgh', initial_data={'password': 'xyzbhvg'})
        self.assertValid('password_confirmation', 'abcdefgh', initial_data={'password': 'abcdefgh'})
