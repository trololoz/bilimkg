from django.test.testcases import TestCase

from user.utils import digits_from_string


class UtilsTest(TestCase):

    def test__digits_from_string(self):
        self.assertEqual(digits_from_string('123456'), '123456')
        self.assertEqual(digits_from_string(' 123-456-F абв'), '123456')
        with self.assertRaises(TypeError):
            digits_from_string(123)
