from django.urls import reverse

from common.tests import CommonTestCase
from user.models import User


class TestMiddleware(CommonTestCase):

    def test__request(self):
        # self.client.force_authenticate(self.user)
        self.client.force_login(self.pupil_user)

        url = reverse('user:user-list')

        self.client.get(url)

        u = User.objects.get(username='test-pupil')
