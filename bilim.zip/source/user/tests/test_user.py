from datetime import timedelta, date

from django.conf import settings
from django.urls import reverse_lazy as reverse
from django.utils import timezone
from rest_framework import status

from common.tests import CommonTestCase, create_user, create_staff
from school.administrative.models import Course
from school.models import School
from user.models import ActivationCode, User, PasswordVerificationCode
from user.profile.models import Staff


class UserTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.base_data = {
            'first_name': 'omurbek uulu',
            'last_name': 'kayrat',
            'phone': '700139680',
            'patronymic': '',
            'email': 'test@test.com',
            'sex': '',
            'additional_phone': '70013-96-80',
            'thumb': None
        }
        self.client.force_login(self.user)

    def test__create(self):
        url = reverse('user:user-list')
        data = self.base_data.copy()
        ret_data = data.copy()
        res = self.client.post(url, data)
        ret = res.json()

        self.assertEqual(res.status_code, status.HTTP_201_CREATED, ret)

        ret_data['last_name'] = data['last_name'].title()
        ret_data['first_name'] = data['first_name'].title()
        ret_data['additional_phone'] = data['additional_phone'].replace('-', '')
        ret_data['sex'] = None

        u_id = ret.pop('pk')
        self.assertDictEqual(ret_data, ret)
        self.assertEqual(User.objects.filter(username='omurbek-uulu-kayrat', id=u_id).count(), 1)

        # Проверяем создание уникального username
        ret_data['email'] = data['email'] = 'test1@test.com'
        res = self.client.post(url, data)
        ret = res.json()
        u_id = ret.pop('pk')

        self.assertEqual(res.status_code, status.HTTP_201_CREATED, ret)
        self.assertEqual(User.objects.filter(username='omurbek-uulu-kayrat-2', id=u_id).count(), 1)
        self.assertDictEqual(ret_data, ret)

    def test__create_incorrect_number(self):
        url = reverse('user:user-list')
        data = self.base_data.copy()
        data['phone'] = '650123456'

        res = self.client.post(url, data)
        ret = res.json()

        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST, ret)
        self.assertIn('phone', ret)

    def test__delete_inactive_users(self):
        inactive_user = create_user(is_active=False)
        expiry_date = timezone.now() - timedelta(days=settings.USER_ACTIVATION_PERIOD+1)
        code = inactive_user.activation_code
        code.add_date = expiry_date
        code.save(update_fields=['add_date'])
        User.delete_inactive_users()
        self.assertFalse(User.objects.filter(pk=inactive_user.pk).exists())


class UserActivationCodeTest(CommonTestCase):
    def test__delete_stale_activation_codes(self):
        active_user = create_user(is_active=True)
        self.assertTrue(hasattr(active_user, 'activation_code'))
        code = active_user.activation_code
        code.add_date = date(2000, 1, 1)
        code.save(update_fields=['add_date'])
        ActivationCode.delete_stale_activation_codes()
        self.assertFalse(hasattr(User.objects.get(pk=active_user.pk), 'activation_code'))


class _BaseUserActivationTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.inactive_user = self._create_inactive_user()

    @staticmethod
    def _create_inactive_user():
        return create_user(is_active=False)


class UserActivationStep1Test(_BaseUserActivationTest):
    def _do_post_test(self, http_status, payload={}):
        response = self.client.post(reverse('user:user-activation-step1'), data=payload)
        ret = response.json()
        self.assertEqual(response.status_code, http_status, ret)
        if http_status == status.HTTP_200_OK:
            self.assertEqual(response.status_code, status.HTTP_200_OK, ret)
            self.assertEqual(ret['user_id'], self.inactive_user.pk)

    def test_post(self):
        # Пустой запрос
        self._do_post_test(status.HTTP_400_BAD_REQUEST)
        # Отправлен только код
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'code': self.inactive_user.activation_code.code
        })
        # Отправлено только имя
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'first_name': self.inactive_user.first_name
        })
        # Отправлена только фамилия
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'last_name': self.inactive_user.last_name
        })
        # Не отправлен активационный код
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'first_name': self.inactive_user.last_name,
            'last_name': self.inactive_user.last_name
        })
        # Пользовтель уже активирован
        self.inactive_user.is_active = True
        self.inactive_user.save(update_fields=['is_active'])
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'first_name': self.inactive_user.first_name,
            'last_name': self.inactive_user.last_name,
            'code': self.inactive_user.activation_code.code
        })
        # Активационный код отсутствует в БД
        self.inactive_user = self._create_inactive_user()
        self.inactive_user.activation_code.delete()
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'first_name': self.inactive_user.first_name,
            'last_name': self.inactive_user.last_name,
            'code': self.inactive_user.activation_code.code
        })
        # Правильные данные
        self.inactive_user = self._create_inactive_user()
        self._do_post_test(status.HTTP_200_OK, payload={
            'first_name': self.inactive_user.first_name,
            'last_name': self.inactive_user.last_name,
            'code': self.inactive_user.activation_code.code
        })


class UserActivationStep2Test(_BaseUserActivationTest):
    def _do_post_test(self, http_status, payload={}):
        response = self.client.post(reverse('user:user-activation-step2'), data=payload)
        self.assertEqual(response.status_code, http_status, response.json())

    def setUp(self):
        super().setUp()
        response = self.client.post(reverse('user:user-activation-step1'), data={
            'first_name': self.inactive_user.first_name,
            'last_name': self.inactive_user.last_name,
            'code': self.inactive_user.activation_code.code
        })
        self.user_id = response.json()['user_id']

    def test_post(self):
        # Пустые данные
        self._do_post_test(status.HTTP_400_BAD_REQUEST)
        # Небезопасный пароль
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'user_id': self.inactive_user.pk,
            'password': '1234',
            'password_confirmation': '1234',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '777123456'
        })
        # Несовпадающие пароли
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': 'zzz',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '777123456'
        })
        # Неправильный ID пользователя
        self._do_post_test(status.HTTP_404_NOT_FOUND, payload={
            'user_id': 0,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '777123456'
        })
        # Неправильный активационный код пользователя
        self._do_post_test(status.HTTP_404_NOT_FOUND, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': '000000',
            'username': 'abcdef123',
            'phone': '777123456'
        })
        # Недопустимый логин
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': self.inactive_user.activation_code.code,
            'username': 'a$$%^*&(^',
            'phone': '777123456'
        })
        # Неверный формат телефона
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '000123456'
        })
        # Неверный формат email
        self._do_post_test(status.HTTP_400_BAD_REQUEST, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '777123456',
            'email': 'abcd'
        })
        # Правильные данные
        self.assertTrue(hasattr(self.inactive_user, 'activation_code'))
        self._do_post_test(status.HTTP_200_OK, payload={
            'user_id': self.inactive_user.pk,
            'password': '6123$wqeuyeqw$12',
            'password_confirmation': '6123$wqeuyeqw$12',
            'code': self.inactive_user.activation_code.code,
            'username': 'abcdef123',
            'phone': '777123456',
            'email': 'abcdef@gmail.com'
        })
        self.inactive_user = User.objects.get(pk=self.inactive_user.pk)
        self.assertTrue(self.inactive_user.is_authenticated)
        self.assertTrue(self.inactive_user.check_password('6123$wqeuyeqw$12'))
        self.assertEqual(self.inactive_user.username, 'abcdef123')
        self.assertEqual(self.inactive_user.phone, '777123456')
        self.assertEqual(self.inactive_user.email, 'abcdef@gmail.com')
        self.assertTrue(self.inactive_user.is_active)


class UserStatusTest(CommonTestCase):
    def _do_permission_test(self, course_url, http_status, as_user=None):
        if as_user is not None:
            self.client.force_login(as_user)
        response = self.client.get(course_url)
        ret = response.json()
        self.assertEqual(response.status_code, http_status, ret)
        if http_status == status.HTTP_200_OK:
            for user_item in ret:
                self.assertIn('pk', user_item)
                self.assertIn('first_name', user_item)
                self.assertIn('last_name', user_item)
                self.assertIn('patronymic', user_item)
                self.assertIn('code', user_item)
                self.assertIn('is_active', user_item)
        self.client.logout()

    def _create_school_head(self):
        return create_staff(
            self.school,
            create_user(email='test-school-head@localhost', username='test-school-head'),
            role=Staff.ROLE_HEAD
        )

    def _create_form_master(self):
        staff = create_staff(self.school, create_user(email='test-form-master@localhost', username='test-form-master'))
        self.course.form_master = staff
        self.course.save()
        return staff

    def setUp(self):
        super().setUp()
        self.course = Course.objects.order_by('?')[0]
        self.school = School.objects.filter(pupil__user__activation_code__isnull=False).order_by('?')[0]
        self.course.school = self.school
        self.course.save()
        # Создаем завуча и классного руководителя
        self.school_head = self._create_school_head()
        self.form_master = self._create_form_master()

    def test_list(self):
        for course in Course.objects.all():
            url = reverse('user:user-status-list', args=[course.pk])
            # Неавторизованный пользователь
            self._do_permission_test(url, status.HTTP_401_UNAUTHORIZED)
            # Авторизованный пользователь
            self._do_permission_test(url, status.HTTP_403_FORBIDDEN, self.user)
            # Работник школы
            self._do_permission_test(url, status.HTTP_403_FORBIDDEN, self.staff.user)
            # Ученик
            self._do_permission_test(url, status.HTTP_403_FORBIDDEN, self.pupil_user)
            # Завуч
            if course.school == self.school:
                self._do_permission_test(url, status.HTTP_200_OK, self.school_head.user)
            else:
                self._do_permission_test(url, status.HTTP_403_FORBIDDEN, self.school_head.user)
            # Классный руководитель
            if course == self.course:
                self._do_permission_test(url, status.HTTP_200_OK, self.form_master.user)
            else:
                self._do_permission_test(url, status.HTTP_403_FORBIDDEN, self.form_master.user)


class UserForgotUsernameTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        create_user(
            email='test-user2@localhost',
            username='test-user-with-email',
            birth_date=date(1980, 1, 1)
        )
        create_user(
            phone='700139680',
            username='test-user-with-phone',
            birth_date=date(1980, 1, 1)
        )

    def _do_post_test(self, data, http_status):
        response = self.client.post(reverse('user:user-forgot-username'), data=data)
        self.assertEqual(response.status_code, http_status, response.json())

    def test_post(self):
        self._do_post_test({}, status.HTTP_400_BAD_REQUEST)
        # Получена только дата рождения
        self._do_post_test({'birth_date': date(1980, 1, 1)}, status.HTTP_400_BAD_REQUEST)
        # Получена дата рождения и эл. почта
        self._do_post_test({'email': 'test-user2@localhost', 'birth_date': date(1980, 1, 1)}, status.HTTP_200_OK)
        # Получена дата рождения и номер телефона
        self._do_post_test({'phone': '700139680', 'birth_date': date(1980, 1, 1)}, status.HTTP_200_OK)


class UserForgotPasswordTest(CommonTestCase):
    def _do_post_test(self, username, http_status):
        response = self.client.post(reverse('user:user-forgot-password'), data={'username': username})
        self.assertEqual(response.status_code, http_status, response.json())

    def setUp(self):
        super().setUp()
        self.user_with_no_contacts = create_user(
            username='test-user-with-no-contacts',
            email='',
            phone=''
        )

    def test_post(self):
        # Правильный логин
        self._do_post_test(self.user.username, status.HTTP_200_OK)
        # Неправильный логин
        self._do_post_test('wrong-username', status.HTTP_400_BAD_REQUEST)
        # Правильный логин, но пользователь без связи
        self._do_post_test(self.user_with_no_contacts.username, status.HTTP_400_BAD_REQUEST)


class UserSetNewPasswordTest(CommonTestCase):
    def _do_post_test(self, code, http_status):
        response = self.client.post(reverse('user:user-set-new-password'), data={
            'username': self.user.username,
            'password': '6123$wqeuyeqw$12',
            'code': code
        })
        self.assertEqual(response.status_code, http_status, response.json())

    def test_post(self):
        # Правильный проверочный код
        pwd_code = PasswordVerificationCode.objects.create(user=self.user)
        self.assertTrue(pwd_code.is_active)
        self._do_post_test(pwd_code.code, status.HTTP_200_OK)
        self.assertFalse(PasswordVerificationCode.objects.get(pk=pwd_code.pk).is_active)
        # Попытка повторного использования неактивного проверочного кода
        self._do_post_test(pwd_code.code, status.HTTP_400_BAD_REQUEST)
        # Неправильный проверочный код
        PasswordVerificationCode.objects.create(user=self.user)
        self._do_post_test('000000', status.HTTP_400_BAD_REQUEST)

    def test_deactivate_old_verification_codes_signal(self):
        old_pwd_code1 = PasswordVerificationCode.objects.create(user=self.user)
        old_pwd_code2 = PasswordVerificationCode.objects.create(user=self.user)
        new_pwd_code = PasswordVerificationCode.objects.create(user=self.user)
        self._do_post_test(old_pwd_code1.code, status.HTTP_400_BAD_REQUEST)
        self._do_post_test(old_pwd_code2.code, status.HTTP_400_BAD_REQUEST)
        self._do_post_test(new_pwd_code.code, status.HTTP_200_OK)
