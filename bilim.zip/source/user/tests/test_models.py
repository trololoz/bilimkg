from datetime import datetime
from common.tests.models import ModelTestCase
from common.tests.utils import create_user
from common.validators import KGMobilePhoneValidator, PinCodeValidator
from user.models import User, ActivationCode


class UserTest(ModelTestCase):
    model = User

    def test_generate_username(self):
        self.assertEqual('карим-абдрахманов', self.model.generate_username('Карим', 'Абдрахманов'))

    def test_kg_mobile_phone_validator(self):
        self.assertValidatorInvalid(KGMobilePhoneValidator, '')
        self.assertValidatorInvalid(KGMobilePhoneValidator, '245674747')
        self.assertValidatorValid(KGMobilePhoneValidator, '559887755')

    def test_pin_code_validator(self):
        self.assertValidatorInvalid(PinCodeValidator, '')
        self.assertValidatorInvalid(PinCodeValidator, 'abcd')
        self.assertValidatorValid(PinCodeValidator, '1234')

    def test_delete_inactive_users(self):
        inactive_user = create_user(is_active=False)
        code = inactive_user.activation_code
        code.add_date = datetime(2000, 1, 1)
        code.save(update_fields=['add_date'])
        self.model.delete_inactive_users()
        self.assertRaises(self.model.DoesNotExist, inactive_user.refresh_from_db)
