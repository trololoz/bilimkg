from rest_framework import serializers

from location.models import City, District, Region


class RegionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Region
        fields = ('pk', 'name')


class CitySerializer(serializers.ModelSerializer):

    class Meta:
        model = City
        fields = ('pk', 'name', 'region')

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['region'] = RegionSerializer(instance.region).data
        return ret


class DistrictSerializer(serializers.ModelSerializer):

    class Meta:
        model = District
        fields = ('pk', 'name', 'city')

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['city'] = CitySerializer(instance.city).data
        return ret
