from django.urls import include, path
from rest_framework.routers import SimpleRouter

from location.views import CityViewSet, DistrictViewSet, RegionViewSet

router = SimpleRouter()
router.register(r'region', RegionViewSet, 'region')
router.register(r'city', CityViewSet, 'city')
router.register(r'district', DistrictViewSet, 'district')

app_name = 'location'
urlpatterns = [
    path('', include(router.urls))
]
