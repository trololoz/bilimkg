from django.db import transaction
from django.urls import reverse
from rest_framework import status

from common.tests import CommonTestCase
from location.models import City, District


class BaseLocationDistrictTestMixin:

    # @classmethod
    # def setUpClass(cls):
    #     cls.fixtures = [
    #         os.path.join(settings.FIXTURES_DIR, 'location-region.json'),
    #         os.path.join(settings.FIXTURES_DIR, 'location-city.json'),
    #         os.path.join(settings.FIXTURES_DIR, 'location-district.json'),
    #     ]
    #     super().setUpClass()

    url_list = reverse('location:district-list')

    def setUp(self):
        super().setUp()
        with transaction.atomic():
            for i in range(10):
                District.objects.create(
                    name='District - {}'.format(i),
                    city_id=City.objects.order_by('?').values_list('pk', flat=True).first()
                )

    def test_create(self):
        self.api_response_test('post', self.url_list, status.HTTP_405_METHOD_NOT_ALLOWED, {'name': 'test district'})

    def test_update(self):
        district_id = District.objects.order_by('?').values_list('pk', flat=True).first()
        url = reverse('location:district-detail', kwargs={'pk': district_id})

        self.api_response_test('post', url, status.HTTP_405_METHOD_NOT_ALLOWED, {'name': 'updated district'})

    def test_list(self):
        cnt = District.objects.count()

        ret = self.api_response_test('get', self.url_list, status.HTTP_200_OK)

        self.assertEqual(cnt, len(ret))

    def test_retrieve(self):
        district = District.objects.order_by('?').first()
        url = reverse('location:district-detail', kwargs={'pk': district.pk})

        ret = self.api_response_test('get', url, status.HTTP_200_OK)

        self.assertDictEqual({
            'pk': district.pk,
            'name': district.name,
            'city': {
                'pk': district.city.pk,
                'name': district.city.name,
                'region': {
                    'pk': district.city.region.pk,
                    'name': district.city.region.name
                }
            }
        }, ret)


class LocationDistrictOfficialTest(BaseLocationDistrictTestMixin, CommonTestCase):

    def setUp(self):
        super().setUp()
        self.client.force_login(self.official.user)


class LocationDistrictStaffTest(BaseLocationDistrictTestMixin, CommonTestCase):

    def setUp(self):
        super().setUp()
        self.client.force_login(self.staff.user)


# class LocationDistrictRelativeTest(BaseLocationDistrictTestMixin, CommonTestCase):

#     def setUp(self):
#         super().setUp()
#         self.client.force_login(self.relative)


class LocationDistrictPupilTest(BaseLocationDistrictTestMixin, CommonTestCase):

    def setUp(self):
        super().setUp()
        self.client.force_login(self.pupil_user)
