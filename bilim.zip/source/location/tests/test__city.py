from django.urls import reverse
from rest_framework import status

from common.tests import CommonTestCase
from location.models import City


class BaseLocationCityTest(CommonTestCase):

    # @classmethod
    # def setUpClass(cls):
    #     cls.fixtures = [
    #         os.path.join(settings.FIXTURES_DIR, 'location-region.json'),
    #         os.path.join(settings.FIXTURES_DIR, 'location-city.json')
    #     ]
    #     super().setUpClass()

    def _create(self):
        url = reverse('location:city-list')
        data = {
            'name': 'test city'
        }
        res = self.client.post(url, data)
        self.assertEqual(res.status_code, status.HTTP_405_METHOD_NOT_ALLOWED, res.json())

    def _update(self):
        city = City.objects.order_by('?').first()
        url = reverse('location:city-detail', kwargs={'pk': city.pk})
        data = {
            'name': 'updated city'
        }
        res = self.client.post(url, data)
        self.assertEqual(res.status_code, status.HTTP_405_METHOD_NOT_ALLOWED, res.json())

    def _list(self):
        url = reverse('location:city-list')

        cnt = City.objects.all().count()

        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(cnt, len(ret))

    def _retrieve(self):
        city = City.objects.order_by('?').first()
        url = reverse('location:city-detail', kwargs={'pk': city.pk})
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual({
            'pk': city.pk,
            'name': city.name,
            'region': {
                'pk': city.region.pk,
                'name': city.region.name,
            }
        }, ret)


class LocationCityOfficialTest(BaseLocationCityTest):

    # def test__create(self):
    #     self.client.force_login(self.official.user)
    #     url = reverse('location:city-list')
    #     region = Region.objects.order_by('?').first()
    #     data = {
    #         'name': 'test city',
    #         'region': region.pk,
    #     }
    #     res = self.client.post(url, data)
    #     self.assertEqual(res.status_code, status.HTTP_201_CREATED, res.json())
    #     ret = res.json()
    #
    #     self.assertEqual('test city', ret.get('name'))
    #     self.assertEqual(region.pk, ret.get('region', {}).get('pk'))
    #
    # def test__update_name(self):
    #     self.client.force_login(self.official.user)
    #     _city = City.objects.order_by('?').first()
    #     url = reverse('location:city-detail', kwargs={'pk': _city.pk})
    #     data = {
    #         'name': 'updated city',
    #     }
    #     res = self.client.patch(url, data)
    #     self.assertEqual(res.status_code, status.HTTP_200_OK)
    #
    #     ret = res.json()
    #     self.assertEqual('updated city', ret.get('name'))
    #     _city.refresh_from_db()
    #     self.assertEqual('updated city', _city.name)
    #
    # def test__update_region(self):
    #     self.client.force_login(self.official.user)
    #     _city = City.objects.order_by('?').first()
    #     _region = Region.objects.order_by('?').exclude(pk=_city.region.pk).first()
    #     url = reverse('location:city-detail', kwargs={'pk': _city.pk})
    #     data = {
    #         'region': _region.pk,
    #     }
    #
    #     res = self.client.patch(url, data)
    #     self.assertEqual(res.status_code, status.HTTP_200_OK)
    #
    #     ret = res.json()
    #     self.assertEqual(_region.pk, ret.get('region', {}).get('pk'))
    #     _city.refresh_from_db()
    #     self.assertEqual(_region.pk, _city.region.pk)

    def test__create(self):
        self.client.force_login(self.official.user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.official.user)
        super()._create()

    def test_list(self):
        self.client.force_login(self.official.user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.official.user)
        super()._retrieve()


class LocationCityStaffTest(BaseLocationCityTest):

    # def test__create(self):
    #     self.client.force_login(self.staff.user)
    #     url = reverse('location:city-list')
    #     region = Region.objects.order_by('?').first()
    #     data = {
    #         'name': 'test city',
    #         'region': region.pk,
    #     }
    #     res = self.client.post(url, data)
    #     self.assertEqual(res.status_code, status.HTTP_201_CREATED, res.json())
    #     ret = res.json()
    #
    #     self.assertEqual('test city', ret.get('name'))
    #     self.assertEqual(region.pk, ret.get('region', {}).get('pk'))

    def test__create(self):
        self.client.force_login(self.staff.user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.staff.user)
        super()._update()

    def test_list(self):
        self.client.force_login(self.staff.user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.staff.user)
        super()._retrieve()


# class LocationCityRelativeTest(BaseLocationCityTest):

#     def test__create(self):
#         self.client.force_login(self.relative)
#         super()._create()

#     def test__update(self):
#         self.client.force_login(self.relative)
#         super()._update()

#     def test_list(self):
#         self.client.force_login(self.relative)
#         super()._list()

#     def test_retrieve(self):
#         self.client.force_login(self.relative)
#         super()._retrieve()


class LocationCityPupilTest(BaseLocationCityTest):

    def test__create(self):
        self.client.force_login(self.pupil_user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.pupil_user)
        super()._update()

    def test_list(self):
        self.client.force_login(self.pupil_user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.pupil_user)
        super()._retrieve()
