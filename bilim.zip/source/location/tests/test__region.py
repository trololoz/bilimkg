from django.urls import reverse
from rest_framework import status

from common.tests import CommonTestCase
from location.models import Region


class BaseLocationRegionTest(CommonTestCase):

    # @classmethod
    # def setUpClass(cls):
    #     cls.fixtures = [os.path.join(settings.FIXTURES_DIR, 'location-region.json')]
    #     super().setUpClass()

    def _create(self):
        url = reverse('location:region-list')
        data = {
            'name': 'test region'
        }
        res = self.client.post(url, data)
        self.assertEqual(res.status_code, status.HTTP_405_METHOD_NOT_ALLOWED, res.json())

    def _update(self):
        region = Region.objects.order_by('?').first()
        url = reverse('location:region-detail', kwargs={'pk': region.pk})
        data = {
            'name': 'updated region'
        }
        res = self.client.post(url, data)
        self.assertEqual(res.status_code, status.HTTP_405_METHOD_NOT_ALLOWED, res.json())

    def _list(self):
        url = reverse('location:region-list')
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(7, len(ret))

    def _retrieve(self):
        region = Region.objects.order_by('?').first()
        url = reverse('location:region-detail', kwargs={'pk': region.pk})
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual({'pk': region.pk, 'name': region.name}, ret)


class LocationRegionOfficialTest(BaseLocationRegionTest):

    def test__create(self):
        self.client.force_login(self.official.user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.official.user)
        super()._create()

    def test_list(self):
        self.client.force_login(self.official.user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.official.user)
        super()._retrieve()


class LocationRegionStaffTest(BaseLocationRegionTest):

    def test__create(self):
        self.client.force_login(self.staff.user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.staff.user)
        super()._create()

    def test_list(self):
        self.client.force_login(self.staff.user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.staff.user)
        super()._retrieve()


# class LocationRegionRelativeTest(BaseLocationRegionTest):

#     def test__create(self):
#         self.client.force_login(self.relative)
#         super()._create()

#     def test__update(self):
#         self.client.force_login(self.relative)
#         super()._create()

#     def test_list(self):
#         self.client.force_login(self.relative)
#         super()._list()

#     def test_retrieve(self):
#         self.client.force_login(self.relative)
#         super()._retrieve()


class LocationRegionPupilTest(BaseLocationRegionTest):

    def test__create(self):
        self.client.force_login(self.pupil_user)
        super()._create()

    def test__update(self):
        self.client.force_login(self.pupil_user)
        super()._create()

    def test_list(self):
        self.client.force_login(self.pupil_user)
        super()._list()

    def test_retrieve(self):
        self.client.force_login(self.pupil_user)
        super()._retrieve()
