from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ModelViewSet

from location.models import City, District, Region
from location.serializers import CitySerializer, DistrictSerializer, RegionSerializer


class RegionViewSet(ModelViewSet):
    http_method_names = ('get', 'head', 'options',)
    permission_classes = (IsAuthenticated, )
    serializer_class = RegionSerializer
    queryset = Region.objects.all()


class CityViewSet(ModelViewSet):
    http_method_names = ('get', 'patch', 'head', 'options',)
    permission_classes = (IsAuthenticated, )
    serializer_class = CitySerializer
    queryset = City.objects.all()


class DistrictViewSet(ModelViewSet):
    http_method_names = ('get', 'patch', 'head', 'options',)
    permission_classes = (IsAuthenticated, )
    serializer_class = DistrictSerializer
    queryset = District.objects.all()
