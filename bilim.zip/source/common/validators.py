import re

from django.core.validators import RegexValidator
from django.utils.translation import gettext_lazy as _


class KGMobilePhoneValidator(RegexValidator):
    regex = re.compile(r'^((5[5|0])|(7[7|0]))\d{7}$')
    message = _('Допустимы только номера мобильных операторов: О!, MegaСom, Beeline')


class PinCodeValidator(RegexValidator):
    regex = re.compile(r'^\d{4}$')
    message = _('Пин-код должен состоять из 4-х цифр.')
