import os

from django.conf import settings
from rest_framework.test import APITestCase

from ministry.models import Subject, Evaluation
from school.models import School
from .utils import get_current_study_year, create_pupil, create_staff, create_user, create_course, create_official, \
    create_teacher, date_range


class _SchoolTestCaseMixin(object):
    fixtures = [
        os.path.join(settings.FIXTURES_DIR, 'developing', 'school.json')
    ]

    def _add_evaluation_to_school(self):
        self.school.evaluation = Evaluation.objects.create(name="Пятибальная система", min_mark=1, max_mark=5)
        self.school.save(update_fields=['evaluation'])

    def setUp(self):
        super().setUp()
        self.school = School.objects.order_by('?').first()
        self._add_evaluation_to_school()
        self.study_year = get_current_study_year()
        self.subject = Subject.objects.create(name="Физическая культура", short_name="Физкультура",
                                              schools=[self.school.pk])
        self.course = create_course(self.school)


class _UserTestCaseMixin(object):
    fixtures = [
        os.path.join(settings.FIXTURES_DIR, 'test', 'ministry-study-year.json')
    ]

    def setUp(self):
        super().setUp()
        self.user = create_user(email='test-user@localhost', username='test-user')
        self.official = create_official(self.user)
        self.pupil_user = create_user(email='test-pupil@localhost', username='test-pupil')
        self.pupil = create_pupil(user=self.pupil_user, study_year=self.study_year)
        self.staff = create_staff(self.school, self.user)


class BaseTestCase(_UserTestCaseMixin, _SchoolTestCaseMixin, APITestCase):
    fixtures = [
        os.path.join(settings.FIXTURES_DIR, 'developing', 'location-region.json'),
        os.path.join(settings.FIXTURES_DIR, 'developing', 'location-city.json'),
        os.path.join(settings.FIXTURES_DIR, 'developing', 'location-district.json'),
    ] + _UserTestCaseMixin.fixtures + _SchoolTestCaseMixin.fixtures

    def api_response_test(self, method, url, http_status, data={}, **kwargs):
        response = getattr(self.client, method)(url, data=data, **kwargs)
        response_json = response.json()
        self.assertEqual(response.status_code, http_status, response_json)
        return response_json
