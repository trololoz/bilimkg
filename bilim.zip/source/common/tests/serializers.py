import random

from django.core.exceptions import ValidationError as DjangoValidationError
from faker import Faker
from rest_framework.exceptions import ValidationError
from .base import BaseTestCase


class SerializerTestCase(BaseTestCase):
    def _validate(self, field_name=None, value=None, initial_data={}):
        if not hasattr(self, 'serializer_class'):
            raise AttributeError("Вы должны задать атрибут `serializer_class`")
        serializer_fields = self.serializer_class.__dict__['_declared_fields']
        data = {}
        for name, type_ in self.serializer_class().get_fields().items():
            type_name = type_.__class__.__name__
            if name == field_name or type_name == 'ReadOnlyField':
                data[name] = value
            elif name in initial_data:
                data[name] = initial_data[name]
            elif name == 'phone':
                data[name] = random.choice(['700139680', '550006733', '559197857', '770847155'])
            else:
                data[name] = self._field_mapping[type_name]
        instance = self.serializer_class(data=data)
        if field_name is None:
            instance.validate(data)
        else:
            getattr(instance, f'validate_{field_name}')(value)

    def setUp(self):
        super().setUp()
        self._field_mapping = self._build_fake_field_mapping()

    def assertValid(self, *args, **kwargs):
        self._validate(*args, **kwargs)

    def assertInvalid(self, *args, **kwargs):
        try:
            self._validate(*args, **kwargs)
        except (ValidationError, DjangoValidationError):
            pass
        else:
            self.fail("Метод не прошел валидацию")

    @staticmethod
    def _build_fake_field_mapping():
        fake = Faker()
        return {
            # Boolean
            'BooleanField': fake.boolean(),
            'NullBooleanField': fake.null_boolean(),
            # String
            'CharField': fake.word(),
            'EmailField': fake.email(),
            'RegexField': r'^abcdefghf$',
            'SlugField': fake.word().lower(),
            'URLField': fake.url(),
            'UUIDField': fake.uuid4(),
            'FilePathField': fake.file_path(),
            'IPAddressField': fake.ipv4_public(),
            # Integer
            'IntegerField': fake.pyint(),
            'FloatField': fake.pyfloat(),
            'DecimalField': fake.pydecimal(),
            # Date and Time
            'DateTimeField': fake.date_time_this_decade(),
            'DateField': fake.date_this_decade(),
            'TimeField': fake.time_object(),
            'DurationField': fake.time_delta(),
            # Choice fields
            'ChoiceField': fake.pyint(),
            # File fields
            'FileField': fake.file_path(),
            'ImageField': fake.file_path(),
            # Other fields
            'PrimaryKeyRelatedField': fake.pyint()
        }
