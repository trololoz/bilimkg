import uuid

from datetime import date, timedelta
from random import randint

from ministry.models import StudyYear
from school.administrative.models import Course
from school.models import School
from user.models import User
from user.profile.models import Official, Pupil, Staff


def get_current_study_year():
    return StudyYear.get_current()


def create_pupil(user: User = None, **kwargs):
    if user is None:
        user = create_user()

    school = School.objects.order_by('?').first()
    course = create_course(school=school)
    data = {
        'current': True,
        'course': course,
        'school': school,
        'study_year': StudyYear.get_current()
    }
    data.update(kwargs)
    return Pupil.objects.create(user=user, **data)


def create_teacher(school, **kwargs):
    return Staff.objects.create(
        school=school,
        user=create_user(),
        **kwargs
    )


def create_user(model=User, **kwargs):
    _str = uuid.uuid4().hex[:8]
    data = {
        'username': f'test-{_str}',
        'first_name': 'Test',
        'last_name': 'User',
        'email': f'test-{_str}@localhost',
        'is_active': True,
        'birth_date': date(randint(1950, 2000), 1, 1)
    }
    data.update(kwargs)
    return model.objects.create(**data)


def create_staff(school, user, **kwargs):
    return Staff.objects.create(school=school, user=user, **kwargs)


def create_official(user):
    return Official.objects.create(user=user)


def create_course(school: School = None, **kwargs):
    def get_parallel(school, study_year):
        """
        Иногда выборка выбрасывает `IntegrityError`, когда данная случайная
        параллель уже существует. Поэтому мы находим другую параллель.
        """
        while True:
            parallel = randint(1, 11)
            if not Course.objects.filter(school=school, index='a', study_year=study_year, parallel=parallel).exists():
                return parallel

    if school is None:
        school = School.objects.order_by('?').first()

    study_year = StudyYear.get_current()
    data = {
        'school': school,
        'parallel': get_parallel(school, study_year),
        'index': 'a',
        'study_year': study_year
    }
    data.update(kwargs)
    return Course.objects.get_or_create(defaults={'name': 'test course'}, **data)[0]


def date_range(start_date: date, end_date: date):
    for n in range(int((end_date - start_date).days)):
        yield start_date + timedelta(n)
