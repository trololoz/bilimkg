# TODO: DEPRECATED
# Строка внизу импортируется как CommonTestCase для того, чтобы не поломать
# существующие тесты. После того как все тесты будут наследоваться от таких
# модулей как common/models.py, common/serializer.py, common/views.py, тогда
# можно будет убрать эту строку совсем.
from .base import BaseTestCase as CommonTestCase
from .utils import *
