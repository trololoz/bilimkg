from django.contrib.sessions.backends.db import SessionStore
from django.http import Http404
from rest_framework.exceptions import ValidationError
from rest_framework.test import APIRequestFactory
from user.models import User
from .base import BaseTestCase


class ViewSetTestCase(BaseTestCase):
    view_kwargs = {}

    def setUp(self):
        super().setUp()
        self.request = APIRequestFactory().get('/')
        self.request.user = User.objects.first()
        self.request.session = SessionStore()
        self.request.query_params = {}

    def assertRaisesValidationError(self, func, *args, **kwargs):
        return self.assertRaises(ValidationError, func, *args, **kwargs)

    def assertRaises404(self, func, *args, **kwargs):
        return self.assertRaises(Http404, func, *args, **kwargs)

    def assertResponseIsOk(self, func):
        return self.assertEqual(func.status_code, 200)

    @property
    def view(self):
        return self.view_class(request=self.request, **self.view_kwargs)
