from django.core.exceptions import ValidationError
from .base import BaseTestCase


class ModelTestCase(BaseTestCase):
    def assertValidatorInvalid(self, validator_class, value):
        self.assertRaises(ValidationError, validator_class(), value)

    def assertValidatorValid(self, validator_class, value):
        self.assertIsNone(validator_class()(value))
