import os

from django.apps import apps
from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):

        for app in settings.BILIM_APPS:
            label = app.split('.')[-1]
            _app = apps.get_app_config(label)

            _env = settings.DJANGO_ENV.lower()

            _app_file = os.path.join(settings.FIXTURES_DIR, _env, f'{_app.label}.json')

            with open(_app_file, "w") as fh:
                call_command('dumpdata', _app.label, '--indent', '4', stdout=fh)
                self.stdout.write(self.style.SUCCESS(f'Successfully created for {_app.label}'))

            for model in _app.get_models():
                _model_file = os.path.join(settings.FIXTURES_DIR, _env, f'{_app.label}-{model._meta.model_name}.json')

                with open(_model_file, "w") as fh:
                    call_command('dumpdata', f'{_app.label}.{model._meta.model_name}', '--indent', '4', stdout=fh)
                    self.stdout.write(
                        self.style.SUCCESS(f'Successfully created for {_app.label}.{model._meta.model_name}'))

        _all_file = os.path.join(settings.FIXTURES_DIR, _env, 'bilim.json')
        with open(_all_file, "w") as fh:
            call_command('dumpdata', '--exclude', 'auth.permission', '--exclude', 'contenttypes', '--indent', '4',
                         stdout=fh)
            self.stdout.write(self.style.SUCCESS(f'Successfully created for bilim'))
