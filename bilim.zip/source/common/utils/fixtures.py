import os

from django.conf import settings
from django.core.management import call_command


def create_fixture(sender, **kwargs):
    """
    After running migrations, go through each of the models
    in the app and ensure the partitions have been setup
    """
    _file = os.path.join(settings.FIXTURES_DIR, f'{sender.name}.json')

    with open(_file, "w") as fh:
        call_command('dumpdata', sender.label, stdout=fh)
