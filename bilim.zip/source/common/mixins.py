import random


class ExtraFieldsMixin:
    def get_fields(self):
        fields = self.get_fields()
        request = self.context['request']

        if request.GET.get('extra'):
            _fields = request.GET.get('extra').split(',')
            for _f in _fields:
                if _f in self._get_extra_dict().keys():
                    fields[_f] = self._get_extra_dict().get(_f)

        return fields


class RandomCodeGeneratorMixin:
    """Генерирует случайный код, состоящий из цифр.

    Нужно добавить поле `code_generation_range`, отвечающее за минимальное и
    максимальное значения генерируемого кода, в наследуемой модели.
    """
    # default value
    code_generation_range = (100000, 99999999)

    def __str__(self):
        return str(self.code)

    def _generate_code(self):
        """Генерирует код активации."""
        return random.randrange(*self.code_generation_range)
