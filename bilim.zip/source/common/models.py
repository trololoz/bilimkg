from django.db import models
from django.utils.translation import ugettext_lazy as _


class BaseTimestampedModel(models.Model):
    date_created = models.DateField(_('Дата создания'), auto_now_add=True)

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=['date_created'], name='date_created_idx')
        ]
