from django.utils.translation import ugettext_lazy as _


class ExceptionBase(Exception):
    default_msg = ''

    def __init__(self, msg: str = None):
        if msg is None:
            msg = self.default_msg
        super().__init__(msg)


class OperationNotAllowed(ExceptionBase):
    default_msg = _('Операция недопустима.')


class BulkDeleteNotAllowed(OperationNotAllowed):
    default_msg = _('Групповое удаление объектов не разрешено.')


class DeleteNotAllowed(OperationNotAllowed):
    default_msg = _('Удаление объекта не разрешено.')


class StudyYearNotSet(ExceptionBase):
    default_msg = _('Текущий учебный год не задан.')