from django.contrib import admin

from journal.models import Journal, Mark


@admin.register(Journal)
class JournalAdmin(admin.ModelAdmin):
    pass


@admin.register(Mark)
class MarkAdmin(admin.ModelAdmin):
    pass
