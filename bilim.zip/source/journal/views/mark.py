from copy import deepcopy

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from journal.models import Mark
from journal.serializers import CreateMarkSerializer, DestroyMarkSerializer, MarkSerializer, UpdateMarkSerializer
from user.permissions import IsSchoolStaff
from user.profile.models import Staff


class BaseMarkViewSet(ModelViewSet):
    lookup_value_regex = '\d+'
    serializer_class = MarkSerializer
    http_method_names = ('get', 'head', 'options',)
    queryset = Mark.objects.all()


# class OfficialMarkViewSet(BaseMarkViewSet):
#     permission_classes = (IsAuthenticated, IsOfficial)


class StaffMarkViewSet(BaseMarkViewSet):
    http_method_names = ('get', 'head', 'post', 'options', 'patch', 'delete')
    permission_classes = (IsAuthenticated, IsSchoolStaff)

    def get_serializer_class(self):
        if self.action:
            if self.action in ['create']:
                return CreateMarkSerializer

            if self.action in ['update', 'partial_update']:
                return UpdateMarkSerializer

            if self.action in ['destroy']:
                return DestroyMarkSerializer

        return self.serializer_class

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def update(self, request, *args, **kwargs):
        # validate data
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=False)
        serializer.is_valid(raise_exception=True)

        data = dict(
            journal=instance.journal,
            pupil=instance.pupil,
            mark_type=instance.mark_type,
            mark=request.data.get('mark'),
            teacher=instance.teacher,
            comment=request.data.get('comment'),
            study_year=instance.study_year,
        )

        instance.is_active = False
        instance.reason = request.data.get('reason')
        instance.save()

        mark = Mark.objects.create(**data)

        return Response(MarkSerializer().to_representation(mark))

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=False)
        serializer.is_valid(raise_exception=True)

        instance.is_active = False
        instance.reason = request.data.get('reason')
        instance.save()
        return Response(MarkSerializer().to_representation(instance))

# class RelativeMarkViewSet(BaseMarkViewSet):
#     permission_classes = (IsAuthenticated, IsRelative)
#
#
# class PupilMarkViewSet(BaseMarkViewSet):
#     permission_classes = (IsAuthenticated, IsPupil)
