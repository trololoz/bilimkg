import logging
from datetime import date, datetime, timedelta

from django.db.models import Avg
from django.shortcuts import get_object_or_404
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from journal.models import Journal, Mark
from journal.serializers import JournalSerializer, MarkSerializer
from ministry.models import Subject
from ministry.serializers import SubjectSerializer
from school.administrative.models import CallSchedule, Classroom, Course, LessonSchedule, SchoolSemester, SchoolSubject
from school.administrative.serializers import (
    LessonScheduleSerializer, SchoolCallScheduleSerializer, SchoolClassRoomSerializer
)
from user.permissions import IsOfficial, IsPupil, IsRelative, IsSchoolStaff
from user.profile.models import Pupil, Staff
from user.profile.serializers import PupilSerializer, StaffSerializer

logger = logging.getLogger('errors')


class BaseJournalViewSet(ModelViewSet):
    lookup_value_regex = '\d+'
    serializer_class = JournalSerializer
    http_method_names = ('get', 'head', 'options',)
    queryset = Journal.objects.all()


class OfficialJournalViewSet(BaseJournalViewSet):
    permission_classes = (IsAuthenticated, IsOfficial)


class StaffJournalViewSet(BaseJournalViewSet):
    """Данные """
    permission_classes = (IsAuthenticated, IsSchoolStaff)

    def list(self, request, *args, **kwargs):
        """ журнал конкретного класса и предмета """
        course_id = kwargs.get('course_id')
        subject_id = kwargs.get('subject_id')

        course = get_object_or_404(Course, pk=int(course_id))
        subject = get_object_or_404(Subject, pk=int(subject_id))

        school_subject = get_object_or_404(SchoolSubject, subject=subject, school=course.school)

        today = date.today()

        date_from_str = request.GET.get('from')
        date_to_str = request.GET.get('to')

        date_from = None
        date_to = None

        if date_from_str:
            try:
                date_from = datetime.strptime(date_from_str, '%Y-%m-%d').date()
            except:
                logger.debug(f'StaffJournalViewSet: invalid date format date_from: {date_from_str}')

        if date_to_str:
            try:
                date_to = datetime.strptime(date_to_str, '%Y-%m-%d').date()
            except:
                logger.debug(f'StaffJournalViewSet: invalid date format date_to: {date_to_str}')

        if not date_from or not date_to:
            date_from = today - timedelta(today.weekday())
            date_to = date_from + timedelta(6)

        data = {
            'schedule': [],
            'pupils': []
        }

        pupils = Pupil.objects.filter(course=course)
        schedule = LessonSchedule.objects.filter(
            course=course,
            subject=school_subject,
            lesson_date__range=(date_from, date_to)
        )

        schedule_data = LessonScheduleSerializer(schedule, many=True).data
        data['schedule'] = schedule_data

        queryset = Journal.objects.filter(
            course=course,
            subject=subject,
            lesson_schedule__in=[s.pk for s in schedule]
        )

        marks = Mark.objects.filter(
            journal__in=[j.pk for j in queryset],
            is_active=True
        )

        _marks = {}
        for mark in marks:
            _key = '{p_id}_{s_id}'.format(p_id=mark.pupil.pk, s_id=mark.journal.lesson_schedule.pk)
            _marks[_key] = MarkSerializer(mark).data

        semester = SchoolSemester.get_current()

        avgs = {a.get('pupil_id'): '{:.2f}'.format(a.get('avg')) for a in
                Mark.objects.filter(
                    journal__course=course,
                    journal__subject=subject,
                    journal__lesson_schedule__semester=semester,
                    is_active=True
                ).values('pupil_id').annotate(avg=Avg('mark')).order_by()}

        for pupil in pupils:
            pupil_data = PupilSerializer(pupil).data
            _mark = []
            for s in schedule:
                _key = '{p_id}_{s_id}'.format(p_id=pupil.pk, s_id=s.pk)
                if _key in _marks:
                    _mark.append(_marks[_key])
                else:
                    _mark.append(None)
            pupil_data['marks'] = _mark
            pupil_data['avg'] = avgs.get(pupil.pk)
            data['pupils'].append(pupil_data)

        return Response(data)


class RelativeJournalViewSet(BaseJournalViewSet):
    permission_classes = (IsAuthenticated, IsRelative)


class PupilJournalViewSet(BaseJournalViewSet):
    permission_classes = (IsAuthenticated, IsPupil)

    def list(self, request, *args, **kwargs):
        data = {
            'schedule': [],
            'teachers': {},
            'call_schedules': {},
            'classroom': {},
            'subjects': {},
        }

        pupil_id = kwargs.get('pupil_id')
        pupil = get_object_or_404(Pupil, pk=int(pupil_id))

        today = date.today()

        date_from_str = request.GET.get('from')
        date_to_str = request.GET.get('to')

        date_from = None
        date_to = None

        if date_from_str:
            try:
                date_from = datetime.strptime(date_from_str, '%Y-%m-%d').date()
            except:
                logger.debug(f'PupilJournalViewSet: invalid date format date_from: {date_from_str}')

        if date_to_str:
            try:
                date_to = datetime.strptime(date_to_str, '%Y-%m-%d').date()
            except:
                logger.debug(f'PupilJournalViewSet: invalid date format date_to: {date_to_str}')

        if not date_from or not date_to:
            date_from = today - timedelta(today.weekday())
            date_to = date_from + timedelta(6)

        schedule = LessonSchedule.objects.filter(
            course=pupil.course,
            lesson_date__range=(date_from, date_to)
        )

        _teachers, _classrooms, _call_schedules, _subjects = set(), set(), set(), set()

        for s in schedule:
            _teachers.add(s.teacher.pk)
            _classrooms.add(s.classroom_id)
            _call_schedules.add(s.call_schedule_id)
            schedule_data = LessonScheduleSerializer(s).data
            schedule_data['lessons'] = []

            for lesson in Journal.objects.filter(course=pupil.course, lesson_schedule=s):
                _subjects.add(lesson.subject_id)
                journal_lesson = JournalSerializer(lesson).data

                marks = []
                for m in Mark.objects.filter(journal=lesson, pupil=pupil, is_active=True):
                    _teachers.add(m.teacher_id)
                    marks.append(MarkSerializer(m).data)
                journal_lesson['marks'] = marks

                schedule_data['lessons'].append(journal_lesson)

            data['schedule'].append(schedule_data)

        data['teachers'] = {s.pk: StaffSerializer(s).data for s in Staff.objects.filter(pk__in=list(_teachers))}

        data['classroom'] = {cr.pk: SchoolClassRoomSerializer(cr).data for cr in
                             Classroom.objects.filter(pk__in=list(_classrooms))}

        data['call_schedules'] = {cs.pk: SchoolCallScheduleSerializer(cs).data for cs in
                                  CallSchedule.objects.filter(pk__in=list(_call_schedules))}

        data['subjects'] = {s.pk: SubjectSerializer(s).data for s in Subject.objects.filter(pk__in=list(_subjects))}

        return Response(data)
