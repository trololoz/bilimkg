import subprocess


def run_architect(apps, schema_editor):
    subprocess.call(["architect", "partition", "--module", "journal.models"])
