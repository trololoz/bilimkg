from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from journal.models import Journal, JournalSemesterResult, Mark
from ministry.serializers import SubjectSerializer
from school.administrative.models import SemesterSubjectResult, Course
from school.administrative.serializers import SchoolCourseSerializer
from user.profile.serializers import PupilSerializer, StaffSerializer


class JournalSerializer(serializers.ModelSerializer):
    class Meta:
        model = Journal
        fields = (
            'pk', 'course', 'subject', 'classwork', 'homework', 'is_check_required',
            'is_mark_required', 'lesson_schedule'
        )

    def to_representation(self, instance, expand=None):
        result = super().to_representation(instance)

        if expand is None:
            return result

        if 'course' in expand:
            result['course'] = SchoolCourseSerializer().to_representation(instance.course)

        if 'subject' in expand:
            result['subject'] = SubjectSerializer().to_representation(instance.subject)

        return result


class BaseMarkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mark
        fields = ('pk', 'journal', 'pupil', 'mark_type', 'mark', 'teacher', 'comment', 'add_time')
        extra_kwargs = {
            'mark_type': {
                'required': True
            }
        }

    def to_representation(self, instance, expand=None):
        result = super().to_representation(instance)
        result['mark_type_str'] = instance.get_mark_type_display()

        if expand is None:
            return result

        if 'journal' in expand:
            result['journal'] = JournalSerializer().to_representation(instance.journal)

        if 'pupil' in expand:
            result['pupil'] = PupilSerializer().to_representation(instance.pupil)

        if 'teacher' in expand:
            result['teacher'] = StaffSerializer().to_representation(instance.teacher)

        return result


class CreateMarkSerializer(BaseMarkSerializer):
    class Meta(BaseMarkSerializer.Meta):
        pass

    def validate(self, attrs):
        journal = attrs['journal']
        pupil = attrs['pupil']
        course = journal.course
        subject = journal.subject
        lesson_schedule = journal.lesson_schedule
        semester = lesson_schedule.semester

        # проверяем принадлежит ли ученик к классу
        if course.id != pupil.course.id:
            raise ValidationError({'pupil': _('Ученик из другого класса')})

        # Проверяем закрыта ли четверть
        if SemesterSubjectResult.objects.filter(semester=semester, subject=subject, closed=True).exists():
            raise ValidationError(_('Четветь закрыта, невозможно выставить оценку'))

        # Проверяем выставлена ли четвертная оценка
        if JournalSemesterResult.objects.filter(pupil=pupil, semester=semester, subject=subject).exists():
            raise ValidationError(_('Ученику уже выставлена четвертная, невозможно выставить оценку'))

        lesson_teacher = lesson_schedule.teacher
        teacher = attrs.get('teacher')

        # оценку может выставлять только учитель который вел
        if lesson_teacher.id != teacher.id:
            raise ValidationError({'teacher': _('Преподаватель может выставить оценку только за свой предмет')})

        if attrs['mark_type'] in [Mark.TYPE_HOMEWORK, Mark.TYPE_CLASSWORK, Mark.TYPE_CONTROL, Mark.TYPE_EXAM,
                                  Mark.TYPE_BEHAVIOR, Mark.TYPE_OTHER] and ('mark' not in attrs or not attrs['mark']):
            raise ValidationError({'mark': _('поле обязательно к заполнению')})

        """у статусной отметки не может быть цифровой оценки."""
        if attrs['mark_type'] in [Mark.STATUS_LATE, Mark.STATUS_ABSENT]:
            attrs['mark'] = None

        return attrs

    def validate_mark(self, value):
        """Валидация оценки на соответствие системе оценок в классе либо в школе."""
        course = Course.objects.select_related('evaluation', 'school').get(journal__pk=self.initial_data['journal'])
        evaluation = course.evaluation or course.school.evaluation
        if value is not None and evaluation is not None:
            min_mark, max_mark = evaluation.min_mark, evaluation.max_mark
            if value < min_mark or value > max_mark:
                raise ValidationError({
                    'mark': _(f'Неверная оценка. Значение должно быть не менее {min_mark} и не более {max_mark}.')
                })
        return value


class UpdateMarkSerializer(BaseMarkSerializer):
    class Meta(BaseMarkSerializer.Meta):
        fields = ('mark', 'comment', 'teacher', 'reason')
        extra_kwargs = {
            'mark': {
                'required': True,
                'allow_null': False,
            },
            'reason': {
                'required': True,
                'allow_blank': False,
                'allow_null': False,
            },
            'teacher': {
                'required': True,
                'allow_null': False,
            }
        }

    def to_representation(self, instance, expand=None):
        super().to_representation(instance, expand)


class DestroyMarkSerializer(BaseMarkSerializer):
    class Meta(BaseMarkSerializer.Meta):
        fields = ('teacher', 'reason')
        extra_kwargs = {
            'reason': {
                'required': True,
                'allow_blank': False,
                'allow_null': False,
            },
            'teacher': {
                'required': True,
                'allow_null': False,
            }
        }

    def to_representation(self, instance, expand=None):
        super().to_representation(instance, expand)


class MarkSerializer(BaseMarkSerializer):
    class Meta(BaseMarkSerializer.Meta):
        pass
