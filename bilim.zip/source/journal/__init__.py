default_app_config = 'journal.apps.JournalConfig'
