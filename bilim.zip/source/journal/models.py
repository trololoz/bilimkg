import architect
from django.db import models
from django.utils.translation import ugettext_lazy as _

from ministry.models import CurrentStudyYearManager, StudyYear, Subject
from school.administrative.models import CallSchedule, Classroom, Course, LessonSchedule, SchoolSemester, SchoolSubject
from user.profile.models import Pupil, Staff


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class Journal(models.Model):
    """
    Журнал
    """
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)

    classwork = models.TextField(null=True, blank=True)
    homework = models.TextField(null=True, blank=True)
    is_check_required = models.BooleanField(default=True)
    is_mark_required = models.BooleanField(default=True)

    lesson_schedule = models.ForeignKey(LessonSchedule, on_delete=models.CASCADE)
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)

    objects = CurrentStudyYearManager()
    default_objects = models.Manager()

    class Meta:
        verbose_name = _('Журнал')
        verbose_name_plural = _('Журналы')


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class Mark(models.Model):
    """
    Отметка в журнале
    """
    TYPE_HOMEWORK = 1
    TYPE_CLASSWORK = 2
    TYPE_CONTROL = 3
    TYPE_EXAM = 4
    TYPE_BEHAVIOR = 5
    TYPE_OTHER = 6

    STATUS_ABSENT = 51
    STATUS_LATE = 52

    TYPES = (
        (TYPE_HOMEWORK, 'homework'),
        (TYPE_CLASSWORK, 'classwork'),
        (TYPE_CONTROL, 'control'),
        (TYPE_EXAM, 'exam'),
        (TYPE_BEHAVIOR, 'behavior'),
        (TYPE_OTHER, 'other'),

        (STATUS_ABSENT, 'absent'),
        (STATUS_LATE, 'late'),
    )

    journal = models.ForeignKey(Journal, on_delete=models.CASCADE, related_name='+')
    pupil = models.ForeignKey(Pupil, on_delete=models.CASCADE, related_name='marks')

    mark_type = models.PositiveSmallIntegerField(choices=TYPES, default=TYPE_CLASSWORK)
    mark = models.PositiveSmallIntegerField(null=True)

    teacher = models.ForeignKey(Staff, on_delete=models.CASCADE)

    comment = models.CharField(max_length=255, null=True, blank=True)
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)

    add_time = models.DateTimeField(auto_now_add=True)

    is_active = models.BooleanField(default=True)
    reason = models.CharField(max_length=255, null=True, blank=True)

    objects = CurrentStudyYearManager()
    default_objects = models.Manager()

    class Meta:
        verbose_name = _('Отметка')
        verbose_name_plural = _('Отметки')


class BaseJournalResult(models.Model):
    # ученик
    pupil = models.ForeignKey(Pupil, on_delete=models.CASCADE)
    # предмет
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    # год обучения
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)
    # кто выставил оценку
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    # оценка
    mark = models.PositiveSmallIntegerField(null=True)

    objects = CurrentStudyYearManager()

    class Meta:
        abstract = True


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class JournalSemesterResult(BaseJournalResult):
    """
    Итоговые оценки за четверть по каждому ученику/предмету
    """
    # четверть
    semester = models.ForeignKey(SchoolSemester, on_delete=models.CASCADE)


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class JournalYearResult(BaseJournalResult):
    """
    Итоговые оценки за год по каждому ученику/предмету
    """
