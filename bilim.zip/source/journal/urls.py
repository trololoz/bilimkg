from django.urls import include, path
from rest_framework.routers import SimpleRouter

from journal.views.journal import (
    OfficialJournalViewSet, PupilJournalViewSet, RelativeJournalViewSet, StaffJournalViewSet
)
from journal.views.mark import StaffMarkViewSet

journal_router = SimpleRouter()
journal_router.register('for-official', OfficialJournalViewSet, 'for-official')
journal_router.register('for-relative', RelativeJournalViewSet, 'for-relative')
journal_router.register('for-pupil', PupilJournalViewSet, 'for-pupil')

journal_staff = SimpleRouter()
journal_staff.register('', StaffJournalViewSet, 'staff-journal')

journal_pupil = SimpleRouter()
journal_pupil.register('', PupilJournalViewSet, 'pupil-journal')

mark_router = SimpleRouter()
# mark_router.register('for-official', OfficialMarkViewSet, 'for-official')
mark_router.register('', StaffMarkViewSet)
# mark_router.register('for-relative', RelativeMarkViewSet, 'for-relative')
# mark_router.register('for-pupil', PupilMarkViewSet, 'for-pupil')

app_name = 'journal'
urlpatterns = [
    path('course/<int:course_id>/<int:subject_id>/', include(journal_staff.urls)),
    path('pupil/<int:pupil_id>/', include(journal_pupil.urls)),
    path('mark/', include((mark_router.urls, app_name), namespace='mark')),
]
