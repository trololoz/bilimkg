import uuid
from datetime import date, time, timedelta
from random import choice, randint

from django.urls import reverse
from rest_framework import status

from common.tests import create_pupil, create_user, date_range, get_current_study_year
from journal.models import Journal, Mark
from journal.tests import BaseJournalTestCase
from ministry.models import Subject
from school.administrative.models import (
    CallSchedule, Classroom, LessonSchedule, SchoolShift, SchoolSubject
)
from user.profile.models import Staff


class JournalPupilTest(BaseJournalTestCase):

    def test__list(self):
        today = date.today()
        from_date = today - timedelta(days=30)
        to_date = today + timedelta(days=30)

        school = self.pupil.school
        course = self.pupil.course

        create_pupil(create_user(), school=school, course=course)

        for s in range(10):
            subject = Subject.objects.create(name='Subject {}'.format(s), short_name='Sub {}'.format(s))
            school_subject = SchoolSubject.objects.create(
                school=school,
                subject=subject
            )

        classroom = Classroom.objects.create(school=school, floor=1, number=101, name='test classroom')
        shift = SchoolShift.objects.create(school=school, name='first')
        call = CallSchedule.objects.create(
            school=school,
            shift=shift,
            index=1,
            from_time=time(hour=8, minute=0),
            till_time=time(hour=8, minute=45)
        )

        for i in range(10):
            t = create_user()
            Staff.objects.create(
                user=t,
                school=school,
                position='{}'.format(uuid.uuid4().hex[:16]),
                role=choice([Staff.ROLE_TEACHER, Staff.ROLE_ASSISTANT])
            )

        LessonSchedule.objects.bulk_create([LessonSchedule(
            school=school,
            course=course,
            subject=SchoolSubject.objects.order_by('?').first(),
            classroom=classroom,
            lesson_date=d,
            call_schedule=call,
            study_year=get_current_study_year(),
            teacher=Staff.objects.filter(school=school).order_by('?').first()
        ) for d in date_range(from_date, to_date)])

        j = []
        for l in LessonSchedule.objects.all():
            j.append(Journal(
                course=course,
                subject=Subject.objects.order_by('?').first(),
                lesson_schedule=l,
                study_year=get_current_study_year()
            ))

        Journal.objects.bulk_create(j)

        marks = []
        for j in Journal.objects.all():
            for i in range(randint(2, 7)):
                marks.append(Mark(
                    journal=j,
                    pupil=self.pupil,
                    mark_type=choice([
                        Mark.TYPE_HOMEWORK,
                        Mark.TYPE_CLASSWORK,
                        Mark.TYPE_CONTROL,
                        Mark.TYPE_EXAM,
                        Mark.TYPE_BEHAVIOR,
                        Mark.TYPE_OTHER
                    ]),
                    mark=randint(2, 5),
                    teacher=j.lesson_schedule.teacher,
                    study_year=get_current_study_year()
                ))

        Mark.objects.bulk_create(marks)

        url = reverse('journal:pupil-journal-list', kwargs={
            'pupil_id': self.pupil.id,
        })

        self.client.force_login(self.pupil_user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
