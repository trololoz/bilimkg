from common.tests import CommonTestCase


class BaseJournalTestCase(CommonTestCase):
    pass
