from datetime import date, time, timedelta
from random import choice, randint

from django.urls import reverse
from rest_framework import status

from common.tests import create_pupil, create_teacher, create_user, date_range
from journal.models import Journal, Mark, StudyYear
from journal.tests import BaseJournalTestCase
from ministry.models import Subject
from school.administrative.models import (
    CallSchedule, Classroom, LessonSchedule, SchoolSemester, SchoolShift, SchoolSubject
)


class JournalStaffTest(BaseJournalTestCase):

    def setUp(self):
        super().setUp()

        today = date.today()
        from_date = today - timedelta(days=30)
        to_date = today + timedelta(days=30)

        school = self.pupil.school
        course = self.pupil.course

        create_pupil(create_user(), school=school, course=course)

        school_subject = SchoolSubject.objects.create(
            school=school,
            subject=self.subject
        )

        classroom = Classroom.objects.create(school=school, floor=1, number=101, name='test classroom')
        shift = SchoolShift.objects.create(school=school, name='first')
        call = CallSchedule.objects.create(
            school=school,
            shift=shift,
            index=1,
            from_time=time(hour=8, minute=0),
            till_time=time(hour=8, minute=45)
        )

        semester_from = today - timedelta(days=60)
        semester_to = today + timedelta(days=30)

        semester = SchoolSemester.objects.create(school=school, name='semester', from_date=semester_from,
                                                 till_date=semester_to)

        LessonSchedule.objects.bulk_create([LessonSchedule(
            school=school,
            course=course,
            subject=school_subject,
            classroom=classroom,
            lesson_date=d,
            call_schedule=call,
            semester=semester,
            study_year=StudyYear.get_current()
        ) for d in date_range(from_date, to_date)])

        j = []
        for l in LessonSchedule.objects.all():
            j.append(Journal(
                course=course,
                subject=self.subject,
                lesson_schedule=l,
                study_year=StudyYear.get_current()
            ))

        Journal.objects.bulk_create(j)

        marks = []
        for j in Journal.objects.all():
            for i in range(randint(2, 7)):
                marks.append(Mark(
                    journal=j,
                    pupil=self.pupil,
                    mark_type=choice([
                        Mark.TYPE_HOMEWORK,
                        Mark.TYPE_CLASSWORK,
                        Mark.TYPE_CONTROL,
                        Mark.TYPE_EXAM,
                        Mark.TYPE_BEHAVIOR,
                        Mark.TYPE_OTHER
                    ]),
                    mark=randint(2, 5),
                    teacher=create_teacher(school),
                    study_year=StudyYear.get_current()
                ))

        Mark.objects.bulk_create(marks)

    def test__course(self):
        course = self.pupil.course

        url = reverse('journal:staff-journal-list', kwargs={
            'course_id': course.id,
            'subject_id': self.subject.pk
        })

        self.client.force_login(self.staff.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(2, len(ret['pupils']))

    def test__course_date_range(self):
        course = self.pupil.course

        url = reverse('journal:staff-journal-list', kwargs={
            'course_id': course.id,
            'subject_id': self.subject.pk
        })

        today = date.today()
        _from = (today - timedelta(days=1)).isoformat()
        _to = today.isoformat()

        self.client.force_login(self.staff.user)
        res = self.client.get(url, {
            'from': _from,
            'to': _to
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(2, len(ret['pupils']))
