from datetime import date, time, timedelta
from random import choice, randint

from django.urls import reverse
from rest_framework import status

from common.tests import create_teacher, date_range, create_staff
from journal.models import Journal, Mark, StudyYear
from journal.tests import BaseJournalTestCase
from ministry.models import Subject
from school.administrative.models import (
    CallSchedule,
    Classroom,
    LessonSchedule,
    SchoolShift,

    SchoolSubject
)
from user.profile.models import Staff


class MarkStaffTest(BaseJournalTestCase):

    def setUp(self):
        super().setUp()

        today = date.today()
        from_date = today - timedelta(days=30)
        to_date = today + timedelta(days=30)

        school = self.pupil.school
        school.evaluation = self.school.evaluation
        school.save(update_fields=['evaluation'])
        self.school = school
        course = self.pupil.course

        subject = Subject.objects.create(name='Физкультура', short_name='Физ-ра')
        school_subject = SchoolSubject.objects.create(
            school=school,
            subject=subject
        )

        classroom = Classroom.objects.create(school=school, floor=1, number=101, name='test classroom')
        shift = SchoolShift.objects.create(school=school, name='first')
        call = CallSchedule.objects.create(
            school=school,
            shift=shift,
            index=1,
            from_time=time(hour=8, minute=0),
            till_time=time(hour=8, minute=45)
        )

        school_staff = create_staff(school, self.user)

        LessonSchedule.objects.bulk_create([LessonSchedule(
            school=school,
            course=course,
            subject=school_subject,
            classroom=classroom,
            lesson_date=d,
            call_schedule=call,
            study_year=StudyYear.get_current(),
            teacher=school_staff,
        ) for d in date_range(from_date, to_date)])

        j = []
        for l in LessonSchedule.objects.all():
            j.append(Journal(
                course=course,
                subject=subject,
                lesson_schedule=l,
                study_year=StudyYear.get_current()
            ))

        Journal.objects.bulk_create(j)

    def test__create(self):
        url = reverse('journal:mark:mark-list')

        _journal = Journal.objects.order_by('?').first()
        _mark_type = choice([Mark.TYPE_HOMEWORK, Mark.TYPE_CLASSWORK, Mark.TYPE_CONTROL, Mark.TYPE_EXAM,
                             Mark.TYPE_BEHAVIOR, Mark.TYPE_OTHER])

        teacher = _journal.lesson_schedule.teacher
        self.client.force_login(teacher.user)

        mark_data = {
            'journal': _journal.pk,
            'pupil': self.pupil.pk,
            'mark_type': _mark_type,
            'teacher': teacher.pk,
            'mark': randint(2, 5),
            'comment': 'mark comment'
        }
        res = self.client.post(url, mark_data)
        self.assertEqual(res.status_code, status.HTTP_201_CREATED, res.json())

        ret = res.json()

        pk = ret.pop('pk')
        _mark = Mark.objects.get(pk=pk)
        self.assertEqual(_mark.journal.pk, _journal.pk)
        self.assertEqual(_mark.pupil.id, self.pupil.pk)
        self.assertEqual(_mark.mark_type, _mark_type)
        self.assertEqual(_mark.teacher.pk, teacher.pk)
        self.assertEqual(_mark.comment, 'mark comment')

        # Оценка должна соответствовать установленной системе оценок
        mark_data['mark'] = self.school.evaluation.max_mark + 1
        res = self.client.post(url, mark_data)
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST, res.json())

    def test__update(self):

        _journal = Journal.objects.order_by('?').first()
        _mark_type = choice([Mark.TYPE_HOMEWORK, Mark.TYPE_CLASSWORK, Mark.TYPE_CONTROL, Mark.TYPE_EXAM,
                             Mark.TYPE_BEHAVIOR, Mark.TYPE_OTHER])

        teacher = _journal.lesson_schedule.teacher
        _mark = Mark.objects.create(**{
            'journal': _journal,
            'pupil': self.pupil,
            'mark_type': _mark_type,
            'mark': randint(2, 5),
            'comment': 'mark comment',
            'teacher': teacher
        })

        url = reverse('journal:mark:mark-detail', kwargs={'pk': _mark.pk})

        self.client.force_login(teacher.user)
        i = randint(2, 5)
        res = self.client.patch(url, {
            'mark': i,
            'comment': 'updated comment',
            'reason': 'reason',
            'teacher': teacher.pk
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        new_pk = ret.pop('pk')

        new_mark = Mark.objects.get(pk=new_pk)

        _mark.refresh_from_db()

        self.assertEqual(_mark.journal.pk, new_mark.journal.pk)
        self.assertEqual(_mark.pupil.pk, new_mark.pupil.pk)
        self.assertEqual(_mark.mark_type, new_mark.mark_type)
        self.assertEqual(new_mark.teacher.pk, teacher.pk)
        self.assertEqual(new_mark.comment, 'updated comment')
        self.assertEqual(new_mark.mark, i)

        self.assertFalse(_mark.is_active)
        self.assertEqual(_mark.reason, 'reason')

    def test__delete(self):
        _journal = Journal.objects.order_by('?').first()
        _mark_type = choice([Mark.TYPE_HOMEWORK, Mark.TYPE_CLASSWORK, Mark.TYPE_CONTROL, Mark.TYPE_EXAM,
                             Mark.TYPE_BEHAVIOR, Mark.TYPE_OTHER])
        teacher = _journal.lesson_schedule.teacher
        _mark = Mark.objects.create(**{
            'journal': _journal,
            'pupil': self.pupil,
            'mark_type': _mark_type,
            'mark': randint(2, 5),
            'comment': 'mark comment',
            'teacher': teacher
        })

        url = reverse('journal:mark:mark-detail', kwargs={'pk': _mark.pk})

        self.client.force_login(teacher.user)
        res = self.client.delete(url, {
            'reason': 'reason',
            'teacher': teacher.pk
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        _mark.refresh_from_db()
        self.assertFalse(_mark.is_active)
        self.assertEqual(_mark.reason, 'reason')
