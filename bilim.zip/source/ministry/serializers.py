from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers

from ministry.models import StudyYear, Subject, Evaluation


class StudyYearSerializer(serializers.ModelSerializer):
    name = serializers.CharField(read_only=True, source='__str__')

    class Meta:
        model = StudyYear
        fields = ('pk', 'name', 'from_year', 'till_year', 'current',)
        extra_kwargs = {
            'current': {
                'validators': []
            }
        }

    def validate(self, data):
        from_year = data.get('from_year')
        till_year = data.get('till_year')
        if from_year is not None and till_year is not None and from_year == till_year:
            raise serializers.ValidationError(_('Начало и окончание учебного года не могут быть одинаковыми.'))
        return data


class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ('pk', 'name', 'short_name', 'schools', 'recommended_hours')


class EvaluationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evaluation
        fields = ('pk', 'name', 'min_mark', 'max_mark', 'default')
