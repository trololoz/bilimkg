from django.contrib import admin

from ministry.models import Evaluation, StudyYear, Subject


@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    pass


@admin.register(StudyYear)
class StudyYearAdmin(admin.ModelAdmin):
    pass


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    pass
