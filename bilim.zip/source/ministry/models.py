from django.contrib.postgres.fields import ArrayField, JSONField
from django.core.cache import cache
from django.db import models
from django.utils.translation import ugettext_lazy as _

from common.exceptions import BulkDeleteNotAllowed, DeleteNotAllowed


class CurrentStudyYearManager(models.Manager):
    """
    Manager для выборки записей текущего учебного года, поле учебного года: study_year
    """

    def get_queryset(self):
        """
        По умолчанию фильтруем все записи по текущему учебному году
        """
        return super().get_queryset().filter(study_year_id=StudyYear.get_current_id())


class StudyYearManager(models.QuerySet):

    def delete(self):
        """
        Удаление объектов запрещено
        """
        raise BulkDeleteNotAllowed


class StudyYear(models.Model):
    CACHE_KEY = 'current-study-year'
    from_year = models.PositiveSmallIntegerField(verbose_name=_('Начальный год'))
    till_year = models.PositiveSmallIntegerField(verbose_name=_('Завершающий год'))
    current = models.NullBooleanField(unique=True, verbose_name=_('Текущий'))

    objects = StudyYearManager.as_manager()

    def __str__(self):
        return '{from_year}/{till_year}'.format(from_year=self.from_year, till_year=self.till_year)

    class Meta:
        unique_together = ('from_year', 'till_year')
        verbose_name = _('Учебный год')
        verbose_name_plural = _('Учебные года')

    def delete(self, *args, **kwargs):
        """
        Удаление объектов запрещено
        """
        raise DeleteNotAllowed

    def save(self, *args, **kwargs):
        if self.current:
            StudyYear.objects.filter(current=True).update(current=None)

        super().save(*args, **kwargs)

        if self.current:
            cache.set(self.CACHE_KEY, None)

    @classmethod
    def get_current_id(cls):
        pk = cache.get(cls.CACHE_KEY, None)

        if not pk:
            try:
                pk = cls.objects.only('pk').get(current=True).pk
            except cls.DoesNotExist:
                return None
            else:
                cache.set(cls.CACHE_KEY, pk)

        return pk

    @classmethod
    def get_current(cls):
        try:
            return cls.objects.get(current=True)
        except cls.DoesNotExist:
            return


class Evaluation(models.Model):
    """
    Система оценки
    """
    name = models.CharField(max_length=64)
    min_mark = models.PositiveSmallIntegerField()
    max_mark = models.PositiveSmallIntegerField()
    default = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('Система оценок')
        verbose_name_plural = _('Системы оценок')


class Subject(models.Model):
    """
    Предмет
    """
    name = models.CharField(max_length=255, unique=True)
    short_name = models.CharField(max_length=128, null=True, blank=True, unique=True)
    schools = ArrayField(models.IntegerField(), blank=True, null=True)
    recommended_hours = JSONField(null=True, blank=True)

    class Meta:
        verbose_name = _('Предмет')
        verbose_name_plural = _('Предметы')

    def __str__(self):
        return self.name
