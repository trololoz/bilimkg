default_app_config = 'ministry.apps.MinistryConfig'
