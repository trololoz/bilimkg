from django.urls import include, path
from rest_framework.routers import SimpleRouter

from ministry.views import StudyYearViewSet, SubjectViewSet, EvaluationViewSet

router = SimpleRouter()
router.register(r'study-year', StudyYearViewSet, 'study-year')
router.register(r'subject', SubjectViewSet, 'subject')
router.register(r'evaluation', EvaluationViewSet, 'evaluation')

app_name = 'ministry'
urlpatterns = [
    path('', include(router.urls))
]
