from rest_framework.permissions import BasePermission, IsAuthenticated
from rest_framework.viewsets import ModelViewSet

from ministry.models import StudyYear, Subject, Evaluation
from ministry.serializers import (
    StudyYearSerializer, SubjectSerializer, EvaluationSerializer
)
from user.models import User


class _MinistryPermissions(BasePermission):
    def has_permission(self, request, view):
        if view.action in ['create', 'update', 'partial_update']:
            return hasattr(request.user, 'roles') and User.ROLE_OFFICIAL in request.user.roles
        else:
            return True

    def has_object_permission(self, request, view, obj):
        return self.has_permission(request, view)


class _BaseMinistryViewSet(ModelViewSet):
    http_method_names = ('get', 'post', 'put', 'patch', 'head', 'options')
    permission_classes = (IsAuthenticated, _MinistryPermissions)


class StudyYearViewSet(_BaseMinistryViewSet):
    serializer_class = StudyYearSerializer
    queryset = StudyYear.objects.order_by('-pk')


class SubjectViewSet(_BaseMinistryViewSet):
    serializer_class = SubjectSerializer
    queryset = Subject.objects.all()


class EvaluationViewSet(_BaseMinistryViewSet):
    serializer_class = EvaluationSerializer
    queryset = Evaluation.objects.all()
