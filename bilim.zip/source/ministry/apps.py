from django.apps import AppConfig


class MinistryConfig(AppConfig):
    name = 'ministry'

    def ready(self):
        super().ready()
        # Hook up Architect to the post migrations signal
        # post_migrate.connect(create_partitions, sender=self)
        # if settings.DJANGO_ENV == 'DEVELOPING':
        #     post_migrate.connect(create_fixture, sender=self)
