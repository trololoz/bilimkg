from django.urls import reverse
from rest_framework import status

from common.tests import CommonTestCase
from ministry.models import StudyYear, Subject, Evaluation


class MinistryStudyYearOfficialTest(CommonTestCase):
    url = reverse('ministry:study-year-list')

    def setUp(self):
        super().setUp()
        self.client.force_login(self.official.user)

    def test__create(self):
        data = {'from_year': 2001,  'till_year': 2002,  'current': False}

        ret = self.api_response_test('post', self.url, status.HTTP_201_CREATED, data)

        ret.pop('pk')
        data['name'] = '2001/2002'
        self.assertDictEqual(data, ret)

    def test__create_unique_years(self):
        data = {'from_year': 2035, 'till_year': 2035}

        ret = self.api_response_test('post', self.url, status.HTTP_400_BAD_REQUEST, data)

        self.assertIn('non_field_errors', ret, ret)

    def test__create_current(self):
        StudyYear.objects.update_or_create(defaults={'current': True}, from_year=2016, till_year=2017)
        self.assertEqual(1, StudyYear.objects.filter(current=True).count())
        data = {'from_year': 2035, 'till_year': 2036, 'current': True}

        ret = self.api_response_test('post', self.url, status.HTTP_201_CREATED, data)

        ret.pop('pk')
        data['name'] = '2035/2036'
        self.assertDictEqual(data, ret)
        self.assertEqual(1, StudyYear.objects.filter(current=True).count())

    def test__list(self):
        ret = self.api_response_test('get', self.url, status.HTTP_200_OK)
        self.assertEqual(StudyYear.objects.count(), len(ret))

    def test__update(self):
        url = reverse('ministry:study-year-detail', kwargs={'pk': StudyYear.get_current_id()})

        self.client.force_login(self.official.user)
        ret = self.api_response_test('patch', url, status.HTTP_200_OK, {'current': True})

        self.assertEqual(ret.get('current'), True)


class MinistryStudyYearReadOnlyTestMixin(object):
    url = reverse('ministry:study-year-list')
    from_year = 2017
    till_year = 2018

    def test__update(self):
        self.api_response_test('patch', self.url, status.HTTP_405_METHOD_NOT_ALLOWED, {'current': True})

    def test__list(self):
        ret = self.api_response_test('get', self.url, status.HTTP_200_OK)
        self.assertEqual(StudyYear.objects.count(), len(ret))


class MinistryStudyYearPupilTest(MinistryStudyYearReadOnlyTestMixin, CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.pupil_user)

    def test__create(self):
        self.api_response_test('post', self.url, status.HTTP_403_FORBIDDEN, {
            'from_year': self.from_year,
            'till_year': self.till_year
        })


class MinistryStudyYearStaffTest(MinistryStudyYearReadOnlyTestMixin, CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.staff.user)

    def test__create(self):
        self.api_response_test('post', self.url, status.HTTP_400_BAD_REQUEST, {
            'from_year': self.from_year,
            'till_year': self.till_year
        })


# class MinistryStudyYearRelativeTest(MinistryStudyYearReadOnlyTestMixin, CommonTestCase):
#     def setUp(self):
#         super().setUp()
#         self.client.force_login(self.relative)


class MinistrySubjectTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.official.user)

    def test__list(self):
        ret = self.api_response_test('get', reverse('ministry:subject-list'), status.HTTP_200_OK)
        self.assertEqual(Subject.objects.count(), len(ret))

    def test__create(self):
        data = {
            'name': "Математический анализ",
            'short_name': "Матан",
            'schools': [self.school.pk]
        }
        ret = self.api_response_test('post', reverse('ministry:subject-list'), status.HTTP_201_CREATED, data)
        self.assertEqual(ret['name'], data['name'])
        self.assertEqual(ret['short_name'], data['short_name'])
        self.assertEqual(ret['schools'], data['schools'])

    def test__patch(self):
        url = reverse('ministry:subject-detail', args=[self.subject.pk])
        ret = self.api_response_test('patch', url, status.HTTP_200_OK, {
            'short_name': "Физ-ра"
        })
        self.assertEqual(ret['short_name'], "Физ-ра")

    def test__put(self):
        url = reverse('ministry:subject-detail', args=[self.subject.pk])
        ret = self.api_response_test('put', url, status.HTTP_200_OK, {
            'name': "Геометрия",
            'short_name': "Геометрия",
            'schools': [self.school.pk]
        })
        self.assertEqual(ret['name'], "Геометрия")
        self.assertEqual(ret['short_name'], "Геометрия")


class MinistryEvaluationTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.official.user)

    def test__list(self):
        ret = self.api_response_test('get', reverse('ministry:evaluation-list'), status.HTTP_200_OK)
        self.assertEqual(Evaluation.objects.count(), len(ret))

    def test__create(self):
        data = {
            'name': "Десятибальная система",
            'min_mark': 1,
            'max_mark': 10,
            'default': True
        }
        ret = self.api_response_test('post', reverse('ministry:evaluation-list'), status.HTTP_201_CREATED, data)
        self.assertEqual(ret['name'], data['name'])
        self.assertEqual(ret['min_mark'], data['min_mark'])
        self.assertEqual(ret['max_mark'], data['max_mark'])
        self.assertIs(ret['default'], data['default'])

    def test__patch(self):
        url = reverse('ministry:evaluation-detail', args=[self.school.evaluation.pk])
        ret = self.api_response_test('patch', url, status.HTTP_200_OK, {
            'min_mark': 2
        })
        self.assertEqual(ret['min_mark'], 2)

    def test__put(self):
        url = reverse('ministry:evaluation-detail', args=[self.school.evaluation.pk])
        ret = self.api_response_test('put', url, status.HTTP_200_OK, {
            'name': "Семибальная система",
            'min_mark': 1,
            'max_mark': 7
        })
        self.assertEqual(ret['name'], "Семибальная система")
        self.assertEqual(ret['max_mark'], 7)
