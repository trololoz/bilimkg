from common.exceptions import DeleteNotAllowed, BulkDeleteNotAllowed
from common.tests.models import ModelTestCase
from ministry.models import StudyYear


class StudyYearTest(ModelTestCase):
    def _remove_current_study_year(self):
        self.current_study_year.current = False
        self.current_study_year.save(update_fields=['current'])

    def setUp(self):
        super().setUp()
        self.current_study_year = StudyYear.objects.only('pk').get(current=True)

    def test_delete(self):
        self.assertRaises(DeleteNotAllowed, self.study_year.delete)
        self.assertRaises(BulkDeleteNotAllowed, StudyYear.objects.all().delete)

    def test_get_current_id(self):
        self.assertEqual(StudyYear.get_current_id(), self.current_study_year.pk)
        self._remove_current_study_year()
        self.assertIsNone(StudyYear.get_current_id())

    def test_get_current(self):
        self.assertEqual(StudyYear.get_current(), self.current_study_year)
        self._remove_current_study_year()
        self.assertIsNone(StudyYear.get_current())
