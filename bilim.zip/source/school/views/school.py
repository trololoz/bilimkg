from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from ministry.models import StudyYear
from school.administrative.models import CallSchedule, Classroom, Course, Housing, SchoolShift
from school.administrative.serializers import (
    SchoolCallScheduleSerializer, SchoolClassRoomSerializer, SchoolCourseSerializer, SchoolHousingSerializer,
    SchoolShiftSerializer
)
from school.filters import SchoolFilter
from school.models import School
from school.serializers.school import SchoolSerializer
from user.models import User
from user.permissions import IsOfficial, IsPupil, IsRelative, IsSchoolStaff, make_profile_permissions
from user.profile.filters import PupilFilter
from user.profile.models import Pupil, Staff
from user.profile.serializers import PupilSerializer, StaffSerializer


class BaseSchoolViewSet(ModelViewSet):
    lookup_value_regex = '\d+'
    serializer_class = SchoolSerializer
    http_method_names = ('get', 'head', 'options',)
    queryset = School.objects.all()
    filter_class = SchoolFilter

    @action(url_path='housings', url_name='housings', detail=True)
    def list_school_housings(self, request, *args, **kwargs):
        """список корпусов школы"""
        instance = self.get_object()
        housings = Housing.objects.filter(school=instance)
        serializer = SchoolHousingSerializer(housings, many=True)
        return Response(serializer.data)

    @action(detail=True, url_path='classrooms', url_name='classrooms')
    def list_school_classrooms(self, request, *args, **kwargs):
        """список кабинетов школы"""
        instance = self.get_object()
        classrooms = Classroom.objects.filter(school=instance)
        serializer = SchoolClassRoomSerializer(classrooms, many=True)
        return Response(serializer.data)

    @action(detail=True, url_path='courses', url_name='courses')
    def list_school_courses(self, request, *args, **kwargs):
        """список классов школы"""
        instance = self.get_object()
        courses = Course.objects.filter(school=instance)
        serializer = SchoolCourseSerializer(courses, many=True)
        return Response(serializer.data)

    @action(detail=True, url_path='staffs', url_name='staffs')
    def list_school_staffs(self, request, *args, **kwargs):
        """список персонала школы"""
        instance = self.get_object()
        staff = Staff.objects.filter(school=instance)
        serializer = StaffSerializer(staff, many=True)
        return Response(serializer.data)

    @action(detail=True, url_path='pupils', url_name='pupils')
    def list_school_pupils(self, request, *args, **kwargs):
        """список учеников школы"""
        instance = self.get_object()

        queryset = Pupil.objects.filter(
            school=instance,
            study_year_id=StudyYear.get_current_id()
        )

        self.filter_class = PupilFilter
        queryset = self.filter_queryset(queryset)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = PupilSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = PupilSerializer(queryset, many=True)

        return Response(serializer.data)

    @action(detail=True, url_path='shifts', url_name='shifts')
    def list_school_shifts(self, request, *args, **kwargs):
        """список смен школы"""
        instance = self.get_object()

        shifts = SchoolShift.objects.filter(school=instance)
        serializer = SchoolShiftSerializer(shifts, many=True)

        return Response(serializer.data)

    @action(detail=True, url_path='calls-schedule', url_name='calls-schedule')
    def list_school_calls_schedule(self, request, *args, **kwargs):
        """список расписания звонков школы"""
        instance = self.get_object()
        call_schedule = CallSchedule.objects.filter(school=instance)
        serializer = SchoolCallScheduleSerializer(call_schedule, many=True)
        return Response(serializer.data)


class OfficialSchoolViewSet(BaseSchoolViewSet):
    """
    Доступ к школам оффициальным лицам
    """
    http_method_names = ('get', 'post', 'put', 'patch', 'head', 'options',)
    permission_classes = (IsAuthenticated, IsOfficial)
    # todo определиться и добавить класс пагинации


class StaffSchoolViewSet(BaseSchoolViewSet):
    """
    Доступ к школе персоналу школы
    """
    http_method_names = ('get', 'patch', 'head', 'options',)
    permission_classes = (IsAuthenticated, IsSchoolStaff)


class RelativeSchoolViewSet(BaseSchoolViewSet):
    """
    Доступ к школе родственникам ученика
    """
    permission_classes = (IsAuthenticated, IsRelative)


class PupilSchoolViewSet(BaseSchoolViewSet):
    """
    Доступ к школе ученикам
    """
    permission_classes = (IsAuthenticated, IsPupil, make_profile_permissions({
        ('retrieve',): (User.ROLE_PUPIL,)
    }))

    def has_object_permission(self, request, obj):
        if hasattr(request.user, 'roles_data'):
            return obj.pk in [po.get('school') for po in request.user.roles_data.get('pupil', [])]
        return False
