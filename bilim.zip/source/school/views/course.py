from rest_framework.decorators import action
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from school.administrative.models import Course
from school.administrative.serializers import SchoolCourseSerializer
from user.profile.models import Pupil
from user.profile.serializers import PupilSerializer


class BaseSchoolCourseViewSet(ModelViewSet):
    lookup_value_regex = '\d+'
    serializer_class = SchoolCourseSerializer
    http_method_names = ('get', 'head', 'options',)
    queryset = Course.objects.all()

    @action(detail=True, url_path='subjects', url_name='subjects')
    def list_subjects(self, request, *args, **kwargs):
        """получение списка предметов в классе"""
        return Response({})

    @action(detail=True, url_path='pupils', url_name='pupils')
    def list_pupils(self, request, *args, **kwargs):
        """получение списка учеников в классе"""
        course_id = kwargs.get('pk')
        course = get_object_or_404(Course, pk=int(course_id))
        pupils = Pupil.objects.filter(course=course)
        return Response(PupilSerializer(pupils, many=True).data)


class OfficialSchoolCourseViewSet(BaseSchoolCourseViewSet):
    pass


class StaffSchoolCourseViewSet(BaseSchoolCourseViewSet):
    pass


class RelativeSchoolCourseViewSet(BaseSchoolCourseViewSet):
    pass


class PupilSchoolCourseViewSet(BaseSchoolCourseViewSet):
    pass
