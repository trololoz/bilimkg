from django.contrib import admin

from school.models import School


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'city']
    list_filter = ['region', ]
    search_fields = ['name']
