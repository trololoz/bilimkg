default_app_config = 'school.public.apps.SchoolPublicConfig'
