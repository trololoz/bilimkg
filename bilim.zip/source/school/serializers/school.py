from rest_framework import serializers

from school.models import School


class BaseSchoolSerializer(serializers.ModelSerializer):
    city = serializers.StringRelatedField()

    class Meta:
        model = School
        fields = (
            'pk',
            'region',
            'city',
            'district',
            'name',
            'description',
            'address',
            'lat',
            'lng',
            'phone',
            'evaluation',
        )
        extra_kwargs = {
            # 'city': {'write_only': True},
            'region': {'write_only': True},
            'district': {'write_only': True},
        }


class SchoolSerializer(BaseSchoolSerializer):
    pass
