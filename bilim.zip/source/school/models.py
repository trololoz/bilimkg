from django.contrib.postgres.fields import JSONField
from django.db import models
from django.utils.translation import ugettext_lazy as _

from location.models import City, District, Region
from user.models import User
from user.profile.models import Staff


class School(models.Model):
    """
    Школа
    """

    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    district = models.ForeignKey(District, null=True, blank=True, on_delete=models.SET_NULL)

    # type = models.PositiveSmallIntegerField(null=True, blank=True,)
    # number = models.PositiveSmallIntegerField(null=True, blank=True,)
    # named = models.CharField(max_length=128, null=True, blank=True, )
    # inclination = models.PositiveSmallIntegerField(null=True, blank=True,)

    name = models.CharField(max_length=128, null=True, blank=True,)
    description = models.TextField(null=True, blank=True,)
    address = models.TextField(null=True, blank=True,)
    lat = models.DecimalField(null=True, blank=True, max_digits=9, decimal_places=9)
    lng = models.DecimalField(null=True, blank=True, max_digits=9, decimal_places=9)
    phone = JSONField(null=True, blank=True)
    evaluation = models.ForeignKey('ministry.Evaluation', null=True, blank=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name = _('Школа')
        verbose_name_plural = _('Школы')

    def __str__(self):
        return self.name

    @property
    def director(self):
        return Staff.objects.get(school=self, role=Staff.ROLE_DIRECTOR)
