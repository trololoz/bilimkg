from django.urls import include, path
from rest_framework.routers import SimpleRouter

from school.views.course import (
    OfficialSchoolCourseViewSet, PupilSchoolCourseViewSet, RelativeSchoolCourseViewSet, StaffSchoolCourseViewSet
)
from school.views.school import (OfficialSchoolViewSet, PupilSchoolViewSet, RelativeSchoolViewSet, StaffSchoolViewSet)

school_router = SimpleRouter()
school_router.register(r'for-official', OfficialSchoolViewSet, 'for-official')
school_router.register(r'for-staff', StaffSchoolViewSet, 'for-staff')
school_router.register(r'for-relative', RelativeSchoolViewSet, 'for-relative')
school_router.register(r'for-pupil', PupilSchoolViewSet, 'for-pupil')

course_router = SimpleRouter()
course_router.register(r'for-official', OfficialSchoolCourseViewSet, 'for-official')
course_router.register(r'for-staff', StaffSchoolCourseViewSet, 'for-staff')
course_router.register(r'for-relative', RelativeSchoolCourseViewSet, 'for-relative')
course_router.register(r'for-pupil', PupilSchoolCourseViewSet, 'for-pupil')


app_name = 'school'
urlpatterns = [
    path('', include(school_router.urls)),
    path('course/', include((course_router.urls, app_name), namespace='course')),
]
