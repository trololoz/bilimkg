from datetime import date

import architect
from django.contrib.postgres.fields import ArrayField
from django.core.validators import MaxValueValidator
from django.db import models
from django.utils.translation import ugettext_lazy as _

from ministry.models import CurrentStudyYearManager, Evaluation, StudyYear, Subject
from school.models import School
from user.models import User


class Housing(models.Model):
    """
    Корпус
    """
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=128)
    short_name = models.CharField(max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('Корпус')
        verbose_name_plural = _('Корпуса')


class Classroom(models.Model):
    """
    Кабинет
    """
    housing = models.ForeignKey(
        Housing,
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    responsible = ArrayField(
        models.IntegerField(),
        blank=True,
        null=True,
    )

    floor = models.PositiveSmallIntegerField()
    number = models.PositiveSmallIntegerField()
    name = models.CharField(max_length=128, blank=True, null=True)  # описательное свойство нр.: Кабинет Биологии

    class Meta:
        verbose_name = _('Кабинет')
        verbose_name_plural = _('Кабинеты')

    def __str__(self):
        return '#{number} {name}'.format(number=self.number, name=self.name)


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class Course(models.Model):
    """
    Класс
    """
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    parallel = models.PositiveSmallIntegerField(validators=[MaxValueValidator(11)])
    index = models.CharField(max_length=3)
    name = models.CharField(max_length=128, blank=True, null=True)
    evaluation = models.ForeignKey(Evaluation, blank=True, null=True, on_delete=models.SET_NULL)
    shift = models.ForeignKey('administrative.SchoolShift',  blank=True, null=True, on_delete=models.SET_NULL)
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)
    form_master = models.ForeignKey('profile.Staff', null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name='master_courses')

    objects = CurrentStudyYearManager()
    default_objects = models.Manager()

    class Meta:
        verbose_name = _('Класс')
        verbose_name_plural = _('Классы')
        ordering = ['parallel', 'index']
        unique_together = ('study_year', 'school', 'parallel', 'index')
        indexes = [
            models.Index(fields=['parallel'], name='parallel_idx'),
            models.Index(fields=['index'], name='index_idx'),
        ]

    def __str__(self):
        return '{} {}'.format(self.parallel, self.index)


#
# class SchoolStaff(models.Model):
#     """
#     Школьный персонал
#     """
#
#     ROLE_DIRECTOR = 1
#     ROLE_HEAD = 2  # завуч
#     ROLE_MANAGER = 3
#     ROLE_PSYCHOLOGIST = 4
#     ROLE_TEACHER = 5
#     ROLE_ASSISTANT = 5  # лаборант
#     ROLE_TRAINEE = 6  # практикант
#
#     ROLES = (
#         (ROLE_DIRECTOR, 'director'),
#         (ROLE_HEAD, 'head'),
#         (ROLE_MANAGER, 'manager'),
#         (ROLE_PSYCHOLOGIST, 'psychologist'),
#         (ROLE_TEACHER, 'teacher'),
#         (ROLE_ASSISTANT, 'assistant'),
#         (ROLE_TRAINEE, 'trainee'),
#     )
#
#     staff = models.ForeignKey('profile.Staff', on_delete=models.CASCADE, related_name='staff_users')
#     school = models.ForeignKey(School, on_delete=models.CASCADE)
#
#     position = models.CharField(max_length=128)  # описательное свойство, нап.: Учитель математики в младших классах
#     role = models.PositiveSmallIntegerField(choices=ROLES, default=ROLE_TEACHER)
#
#     class Meta:
#         ordering = ['role']


class SchoolSubject(models.Model):
    """
    Список предметов в школе
    """
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)
    teachers = models.ManyToManyField('profile.Staff', blank=True)

    class Meta:
        unique_together = ('school', 'subject')

    def __str__(self):
        return self.subject.name


class SchoolShift(models.Model):
    """
    Смена
    """
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=64)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('Смена')
        verbose_name_plural = _('Смены')


class CallSchedule(models.Model):
    """
    Расписание звонков
    """
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    shift = models.ForeignKey(SchoolShift, on_delete=models.CASCADE)
    index = models.PositiveSmallIntegerField()

    from_time = models.TimeField()
    till_time = models.TimeField()

    class Meta:
        verbose_name = _('Расписание звонков')
        verbose_name_plural = _('Расписания звонков')


class CourseGroup(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    subject = models.ForeignKey(SchoolSubject, on_delete=models.CASCADE)


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class LessonSchedule(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    group = models.ForeignKey(CourseGroup, null=True, blank=True, on_delete=models.CASCADE)

    subject = models.ForeignKey(SchoolSubject, on_delete=models.CASCADE)
    teacher = models.ForeignKey('profile.Staff', null=True, on_delete=models.SET_NULL)

    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)

    lesson_date = models.DateField()
    call_schedule = models.ForeignKey(CallSchedule, on_delete=models.CASCADE)

    semester = models.ForeignKey('administrative.SchoolSemester', null=True, on_delete=models.CASCADE)
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)

    objects = CurrentStudyYearManager()
    default_objects = models.Manager()


class SchoolSemester(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=64)
    from_date = models.DateField()
    till_date = models.DateField()
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE)

    objects = CurrentStudyYearManager()

    def __str__(self):
        return self.name

    @classmethod
    def get_from_date(cls, from_date):
        return cls.objects.get(from_date__lte=from_date, till_date__gte=from_date)

    @classmethod
    def get_current(cls):
        from_date = date.today()
        return cls.get_from_date(from_date)

    def save(self, *args, **kwargs):
        if self.study_year_id is None:
            self.study_year = StudyYear.get_current()

        super().save(*args, **kwargs)


@architect.install('partition', type='range', subtype='integer', constraint='1', column='study_year_id')
class SemesterSubjectResult(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    closed = models.BooleanField(default=False)
    staff = models.ForeignKey('profile.Staff', on_delete=models.CASCADE)
    semester = models.ForeignKey(SchoolSemester, on_delete=models.CASCADE)
    study_year = models.ForeignKey(StudyYear, on_delete=models.CASCADE, default=StudyYear.get_current_id)

    objects = CurrentStudyYearManager()
