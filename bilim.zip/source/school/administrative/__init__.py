default_app_config = 'school.administrative.apps.SchoolAdministrativeConfig'
