from django.urls import include, path
from rest_framework.routers import SimpleRouter

from .views import (
    SchoolHousingViewSet, SchoolClassRoomViewSet, SchoolCourseViewSet, SchoolShiftViewSet,
    SchoolCallScheduleViewSet, LessonScheduleViewSet, SchoolSemesterViewSet
)

router = SimpleRouter()
router.register(r'school-housing', SchoolHousingViewSet, 'school-housing')
router.register(r'school-classroom', SchoolClassRoomViewSet, 'school-classroom')
router.register(r'school-course', SchoolCourseViewSet, 'school-course')
# router.register(r'school-staff', SchoolStaffViewSet, 'school-staff')
router.register(r'school-shift', SchoolShiftViewSet, 'school-shift')
router.register(r'school-callschedule', SchoolCallScheduleViewSet, 'school-callschedule')
router.register(r'school-lessonschedule', LessonScheduleViewSet, 'school-lessonschedule')
router.register(r'school-semester', SchoolSemesterViewSet, 'school-semester')

app_name = 'school.administrative'
urlpatterns = [
    path('', include(router.urls)),
]
