from rest_framework import serializers

from ministry.serializers import SubjectSerializer
from school.administrative.models import (
    CallSchedule,
    Classroom,
    Course,
    Housing,
    LessonSchedule,
    SchoolSemester,
    SchoolShift,
    SchoolSubject
)
from user.profile.serializers import StaffSerializer


class SchoolHousingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Housing
        fields = ('pk', 'school', 'name', 'short_name')


class SchoolClassRoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Classroom
        fields = ('pk', 'school', 'housing', 'responsible', 'floor', 'number', 'name')


class SchoolCourseSerializer(serializers.ModelSerializer):
    as_str = serializers.CharField(source='__str__', read_only=True)

    class Meta:
        model = Course
        fields = (
            'pk', 'as_str', 'school', 'parallel', 'index', 'name', 'evaluation', 'shift', 'form_master', 'study_year')


# class SchoolStaffSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = SchoolStaff
#         fields = ('staff', 'school', 'position', 'role')


class SchoolShiftSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolShift
        fields = ('pk', 'name', 'school')


class SchoolCallScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CallSchedule
        fields = ('pk', 'school', 'shift', 'index', 'from_time', 'till_time')


class LessonScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonSchedule
        fields = ('pk', 'school', 'course', 'group', 'subject', 'teacher', 'classroom', 'lesson_date', 'call_schedule',
                  'semester', 'study_year')

    def to_representation(self, instance, expand=None):
        result = super().to_representation(instance)

        if expand is None:
            return result

        if 'call_schedule' in expand:
            result['call_schedule'] = SchoolCallScheduleSerializer().to_representation(instance.call_schedule)

        if 'classroom' in expand:
            result['classroom'] = SchoolClassRoomSerializer().to_representation(instance.classroom)

        return result


class SchoolSemesterSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolSemester
        fields = ('pk', 'school', 'name', 'from_date', 'till_date', 'study_year')


class SchoolSubjectSerializer(serializers.ModelSerializer):
    teachers = StaffSerializer(many=True)
    subject = SubjectSerializer()

    class Meta:
        model = SchoolSubject
        fields = ('pk', 'school', 'subject', 'parent', 'teachers')
