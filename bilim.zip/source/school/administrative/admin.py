from django.contrib import admin

from school.administrative.models import (
    CallSchedule, Classroom, Course, CourseGroup, Housing, SchoolShift,
    SchoolSubject
)


@admin.register(CallSchedule)
class CallScheduleAdmin(admin.ModelAdmin):
    pass


@admin.register(Classroom)
class ClassroomAdmin(admin.ModelAdmin):
    pass


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    pass


@admin.register(CourseGroup)
class CourseGroupAdmin(admin.ModelAdmin):
    pass


@admin.register(Housing)
class HousingAdmin(admin.ModelAdmin):
    pass


@admin.register(SchoolShift)
class SchoolShiftAdmin(admin.ModelAdmin):
    pass


#
# @admin.register(SchoolStaff)
# class SchoolStaffAdmin(admin.ModelAdmin):
#     pass


@admin.register(SchoolSubject)
class SchoolSubjectAdmin(admin.ModelAdmin):
    pass
