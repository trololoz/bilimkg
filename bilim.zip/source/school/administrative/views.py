from rest_framework import viewsets
from .serializers import (
    SchoolHousingSerializer, SchoolClassRoomSerializer, SchoolCourseSerializer, SchoolShiftSerializer,
    SchoolCallScheduleSerializer, LessonScheduleSerializer, SchoolSemesterSerializer
)
from .models import Housing, Classroom, Course, SchoolShift, CallSchedule, LessonSchedule, SchoolSemester


class SchoolHousingViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolHousingSerializer
    queryset = Housing.objects.all()


class SchoolClassRoomViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolClassRoomSerializer
    queryset = Classroom.objects.all()


class SchoolCourseViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolCourseSerializer
    queryset = Course.objects.all()


# class SchoolStaffViewSet(viewsets.ModelViewSet):
#     serializer_class = SchoolStaffSerializer
#     queryset = SchoolStaff.objects.all()


class SchoolShiftViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolShiftSerializer
    queryset = SchoolShift.objects.all()


class SchoolCallScheduleViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolCallScheduleSerializer
    queryset = CallSchedule.objects.all()


class LessonScheduleViewSet(viewsets.ModelViewSet):
    serializer_class = LessonScheduleSerializer
    queryset = LessonSchedule.objects.all()


class SchoolSemesterViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolSemesterSerializer
    queryset = SchoolSemester.objects.all()
