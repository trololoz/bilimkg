from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from school.administrative.models import Classroom, Housing


class SchoolClassRoomTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.housing = Housing.objects.create(school=self.school, name="Школьное здание", short_name="Здание")
        self.classroom = Classroom.objects.create(
            school=self.school,
            floor=5,
            number=3,
            name="Кабинет Географии",
            housing=self.housing
        )

    def test_post(self):
        response = self.client.post(reverse('administrative:school-classroom-list'), {
            'school': self.school.pk,
            'name': "Кабинет Математики",
            'housing': self.housing.pk,
            'floor': 2,
            'number': 4
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(Classroom.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-classroom-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(Classroom.objects.filter(pk=self.classroom.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-classroom-detail', args=[self.classroom.pk]), {
            'school': self.school.pk,
            'name': "Кабинет Физики",
            'housing': self.housing.pk,
            'floor': 5,
            'number': 1
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.classroom.refresh_from_db()
        self.assertEqual(self.classroom.name, "Кабинет Физики")
        self.assertEqual(self.classroom.number, 1)

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-classroom-detail', args=[self.classroom.pk]), {
            'name': "Кабинет Информатики"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.classroom.refresh_from_db()
        self.assertEqual(self.classroom.name, "Кабинет Информатики")

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-classroom-detail', args=[self.classroom.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Classroom.objects.filter(pk=self.classroom.pk).exists())
