from datetime import date
from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from ministry.models import Subject
from user.profile.models import Staff
from school.administrative.models import (
    CallSchedule, SchoolShift, LessonSchedule, CourseGroup, SchoolSubject, SchoolSemester, Housing, Classroom
)


class LessonScheduleTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.shift = SchoolShift.objects.create(school=self.school, name="Первая смена")
        self.callschedule = CallSchedule.objects.create(
            school=self.school,
            shift=self.shift,
            index=3,
            from_time='09:00',
            till_time='10:00'
        )
        self.teacher = Staff.objects.create(
            school=self.school,
            position="Лаборант в старших классах",
            user=self.user,
            role=Staff.ROLE_ASSISTANT
        )
        self.school_subject = SchoolSubject.objects.create(school=self.school, subject=self.subject)
        self.school_subject.teachers.add(self.teacher)
        self.housing = Housing.objects.create(school=self.school, name="Школьное здание", short_name="Здание")
        self.classroom = Classroom.objects.create(
            school=self.school,
            floor=5,
            number=3,
            name="Кабинет Географии",
            housing=self.housing
        )
        self.semester = SchoolSemester.objects.create(
            school=self.school,
            name="Первая четверть",
            from_date=date(2018, 1, 1),
            till_date=date(2018, 6, 1),
            study_year=self.study_year
        )
        self.lessonschedule = LessonSchedule.objects.create(
            school=self.school,
            course=self.course,
            teacher=self.teacher,
            subject=self.school_subject,
            classroom=self.classroom,
            lesson_date=date(2018, 3, 3),
            call_schedule=self.callschedule,
            semester=self.semester,
            study_year=self.study_year
        )

    def test_post(self):
        response = self.client.post(reverse('administrative:school-lessonschedule-list'), {
            'school': self.school.pk,
            'course': self.course.pk,
            'teacher': self.teacher.pk,
            'subject': self.school_subject.pk,
            'classroom': self.classroom.pk,
            'lesson_date': date(2018, 4, 4),
            'call_schedule': self.callschedule.pk,
            'semester': self.semester.pk,
            'study_year': self.study_year.pk
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(LessonSchedule.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-lessonschedule-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(LessonSchedule.objects.filter(pk=self.lessonschedule.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-lessonschedule-detail', args=[self.lessonschedule.pk]), {
            'school': self.school.pk,
            'course': self.course.pk,
            'teacher': self.teacher.pk,
            'subject': self.school_subject.pk,
            'classroom': self.classroom.pk,
            'lesson_date': date(2005, 1, 1),
            'call_schedule': self.callschedule.pk,
            'semester': self.semester.pk,
            'study_year': self.study_year.pk
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.lessonschedule.refresh_from_db()
        self.assertEqual(self.lessonschedule.lesson_date, date(2005, 1, 1))

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-lessonschedule-detail', args=[self.lessonschedule.pk]), {
            'lesson_date': date(2008, 5, 10)
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.lessonschedule.refresh_from_db()
        self.assertEqual(self.lessonschedule.lesson_date, date(2008, 5, 10))

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-lessonschedule-detail', args=[self.lessonschedule.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(LessonSchedule.objects.filter(pk=self.lessonschedule.pk).exists())
