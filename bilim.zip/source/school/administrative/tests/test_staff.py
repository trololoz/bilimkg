# from django.urls import reverse_lazy as reverse
# from rest_framework import status

# from common.tests import CommonTestCase
# from school.administrative.models import SchoolStaff


# class SchoolStaffTest(CommonTestCase):
#     def setUp(self):
#         super().setUp()
#         self.client.force_login(self.user)
#         self.school_staff = SchoolStaff.objects.create(
#             school=self.school,
#             staff=self.staff,
#             position="Лаборант в старших классах",
#             role=SchoolStaff.ROLE_ASSISTANT
#         )

#     def test_post(self):
#         response = self.client.post(reverse('administrative:school-staff-list'), {
#             'school': self.school.pk,
#             'staff': self.staff.pk,
#             'position': "Учитель математики в младших классах",
#             'role': SchoolStaff.ROLE_TEACHER
#         })
#         ret = response.json()
#         self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
#         self.assertTrue(SchoolStaff.objects.filter(pk=ret['pk']).exists())

#     def test_list(self):
#         response = self.client.get(reverse('administrative:school-staff-list'))
#         self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
#         self.assertTrue(SchoolStaff.objects.filter(pk=self.school_staff.pk).exists())

#     def test_put(self):
#         response = self.client.put(reverse('administrative:school-staff-detail', args=[self.school_staff.pk]), {
#             'school': self.school.pk,
#             'staff': self.staff.pk,
#             'position': "Практикант по английскому языку в средних классах",
#             'role': SchoolStaff.ROLE_TRAINEE
#         })
#         self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
#         self.assertEqual(SchoolStaff.objects.get(pk=self.school_staff.pk).position,
#                          "Практикант по английскому языку в средних классах")
#         self.assertEqual(SchoolStaff.objects.get(pk=self.school_staff.pk).role, SchoolStaff.ROLE_TRAINEE)

#     def test_patch(self):
#         response = self.client.patch(reverse('administrative:school-staff-detail', args=[self.school_staff.pk]), {
#             'role': SchoolStaff.ROLE_HEAD
#         })
#         self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
#         self.assertEqual(SchoolStaff.objects.get(pk=self.school_staff.pk).role, SchoolStaff.ROLE_HEAD)

#     def test_delete(self):
#         response = self.client.delete(reverse('administrative:school-staff-detail', args=[self.school_staff.pk]))
#         self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
#         self.assertFalse(SchoolStaff.objects.filter(pk=self.school_staff.pk).exists())
