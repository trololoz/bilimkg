from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from school.administrative.models import Housing


class SchoolHousingTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.housing = Housing.objects.create(school=self.school, name="Test Name", short_name="Name")

    def test_post(self):
        response = self.client.post(reverse('administrative:school-housing-list'), {
            'school': self.school.pk,
            'name': "Школьное здание 1",
            'short_name': "Здание 1"
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(Housing.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-housing-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(Housing.objects.filter(pk=self.housing.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-housing-detail', args=[self.housing.pk]), {
            'school': self.school.pk,
            'name': "Новое школьное здание 1",
            'short_name': "Новое здание 1"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.housing.refresh_from_db()
        self.assertEqual(self.housing.name, "Новое школьное здание 1")
        self.assertEqual(self.housing.short_name, "Новое здание 1")

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-housing-detail', args=[self.housing.pk]), {
            'name': "Новое школьное здание 2"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.housing.refresh_from_db()
        self.assertEqual(self.housing.name, "Новое школьное здание 2")

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-housing-detail', args=[self.housing.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Housing.objects.filter(pk=self.housing.pk).exists())
