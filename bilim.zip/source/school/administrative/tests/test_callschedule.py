from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from school.administrative.models import CallSchedule, SchoolShift


class CallScheduleTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.shift = SchoolShift.objects.create(school=self.school, name="Первая смена")
        self.callschedule = CallSchedule.objects.create(
            school=self.school,
            shift=self.shift,
            index=3,
            from_time='09:00',
            till_time='10:00'
        )

    def test_post(self):
        response = self.client.post(reverse('administrative:school-callschedule-list'), {
            'school': self.school.pk,
            'shift': self.shift.pk,
            'index': 4,
            'from_time': '10:30',
            'till_time': '11:30'
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(CallSchedule.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-callschedule-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(CallSchedule.objects.filter(pk=self.callschedule.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-callschedule-detail', args=[self.callschedule.pk]), {
            'school': self.school.pk,
            'shift': self.shift.pk,
            'index': 5,
            'from_time': '11:30',
            'till_time': '11:45'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.callschedule.refresh_from_db()
        self.assertEqual(self.callschedule.index, 5)
        self.assertEqual(self.callschedule.from_time.strftime('%H:%M'), '11:30')
        self.assertEqual(self.callschedule.till_time.strftime('%H:%M'), '11:45')

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-callschedule-detail', args=[self.callschedule.pk]), {
            'index': 1
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.callschedule.refresh_from_db()
        self.assertEqual(self.callschedule.index, 1)

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-callschedule-detail', args=[self.callschedule.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(CallSchedule.objects.filter(pk=self.callschedule.pk).exists())
