from datetime import date
from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from school.administrative.models import SchoolSemester


class SchoolSemesterTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.semester = SchoolSemester.objects.create(
            school=self.school,
            name="Первая четверть",
            from_date=date(2017, 1, 1),
            till_date=date(2017, 6, 1),
            study_year=self.study_year
        )

    def test_post(self):
        response = self.client.post(reverse('administrative:school-semester-list'), {
            'school': self.school.pk,
            'name': "Вторая четверть",
            'from_date': date(2010, 6, 1),
            'till_date': date(2010, 12, 31),
            'study_year': self.study_year.pk
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(SchoolSemester.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-semester-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(SchoolSemester.objects.filter(pk=self.semester.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-semester-detail', args=[self.semester.pk]), {
            'school': self.school.pk,
            'name': "Третья четверть",
            'from_date': date(2017, 7, 15),
            'till_date': date(2017, 9, 20),
            'study_year': self.study_year.pk
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.semester.refresh_from_db()
        self.assertEqual(self.semester.name, "Третья четверть")
        self.assertEqual(self.semester.from_date, date(2017, 7, 15))
        self.assertEqual(self.semester.till_date, date(2017, 9, 20))

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-semester-detail', args=[self.semester.pk]), {
            'name': "Вторая четверть"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.semester.refresh_from_db()
        self.assertEqual(self.semester.name, "Вторая четверть")

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-semester-detail', args=[self.semester.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(SchoolSemester.objects.filter(pk=self.semester.pk).exists())
