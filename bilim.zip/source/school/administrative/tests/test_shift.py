from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from school.administrative.models import SchoolShift


class SchoolShiftTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.shift = SchoolShift.objects.create(school=self.school, name="Первая смена")

    def test_post(self):
        response = self.client.post(reverse('administrative:school-shift-list'), {
            'school': self.school.pk,
            'name': "Вторая смена"
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(SchoolShift.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-shift-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(SchoolShift.objects.filter(pk=self.shift.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-shift-detail', args=[self.shift.pk]), {
            'school': self.school.pk,
            'name': "Вторая смена"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.shift.refresh_from_db()
        self.assertEqual(self.shift.name, "Вторая смена")

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-shift-detail', args=[self.shift.pk]), {
            'name': "Вторая смена"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.shift.refresh_from_db()
        self.assertEqual(self.shift.name, "Вторая смена")

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-shift-detail', args=[self.shift.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(SchoolShift.objects.filter(pk=self.shift.pk).exists())
