from django.urls import reverse_lazy as reverse
from rest_framework import status

from common.tests import CommonTestCase
from ministry.models import Evaluation
from school.administrative.models import Course, SchoolShift


class SchoolCourseTest(CommonTestCase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.evaluation = Evaluation.objects.create(name="Test Name", min_mark=1, max_mark=5)
        self.shift = SchoolShift.objects.create(school=self.school, name="Первая смена")

    def test_post(self):
        response = self.client.post(reverse('administrative:school-course-list'), {
            'school': self.school.pk,
            'parallel': 6,
            'index': 'A',
            'name': "Физкультура",
            'evaluation': self.evaluation.pk,
            'shift': self.shift.pk,
            'study_year': self.study_year.pk,
            'form_master': self.staff.pk
        })
        ret = response.json()
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, ret)
        self.assertTrue(Course.objects.filter(pk=ret['pk']).exists())

    def test_list(self):
        response = self.client.get(reverse('administrative:school-course-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(Course.objects.filter(pk=self.course.pk).exists())

    def test_put(self):
        response = self.client.put(reverse('administrative:school-course-detail', args=[self.course.pk]), {
            'school': self.school.pk,
            'parallel': 4,
            'index': 'Д',
            'name': "География",
            'evaluation': self.evaluation.pk,
            'shift': self.shift.pk,
            'study_year': self.study_year.pk,
            'form_master': self.staff.pk
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.course.refresh_from_db()
        self.assertEqual(self.course.name, "География")
        self.assertEqual(self.course.index, 'Д')
        self.assertEqual(self.course.parallel, 4)

    def test_patch(self):
        response = self.client.patch(reverse('administrative:school-course-detail', args=[self.course.pk]), {
            'name': "Музыка"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.course.refresh_from_db()
        self.assertEqual(self.course.name, "Музыка")

    def test_delete(self):
        response = self.client.delete(reverse('administrative:school-course-detail', args=[self.course.pk]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Course.objects.filter(pk=self.course.pk).exists())
