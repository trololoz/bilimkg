from django.urls import reverse
from rest_framework import status

from school.tests import BaseCourseTestCase
from user.profile.models import Pupil


class CoursePupilTest(BaseCourseTestCase):

    def test__list_subjects(self):
        url = reverse('school:course:for-pupil-subjects', kwargs={'pk': self.pupil.course.id})

        self.client.force_login(self.pupil_user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())

    def test__list_pupils(self):
        url = reverse('school:course:for-pupil-pupils', kwargs={'pk': self.pupil.course.id})
        self.client.force_login(self.pupil_user)

        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        cnt = Pupil.objects.filter(course=self.pupil.course).count()
        self.assertEqual(cnt, len(ret))
