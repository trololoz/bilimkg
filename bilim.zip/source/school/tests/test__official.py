from django.urls import reverse
from rest_framework import status

from location.models import Region
from school.models import School
from school.tests import BaseSchoolTestCase


class SchoolOfficialTest(BaseSchoolTestCase):

    def test__list(self):
        url = reverse('school:for-official-list')
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

    def test__create(self):
        url = reverse('school:for-official-list')
        region = Region.objects.order_by('?').first()
        city = region.city_set.order_by('?').first()
        self.client.force_login(self.official.user)
        res = self.client.post(url, {
            'name': 'test school',
            'city': city.id,
            'region': region.id
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED, res.json())
        ret = res.json()

        self.assertEqual('test school', ret.get('name'))
        new_school = School.objects.get(pk=ret.get('pk'))
        self.assertEqual('test school', new_school.name)

    def test__update(self):
        school = School.objects.order_by('?').first()
        url = reverse('school:for-official-detail', kwargs={'pk': school.id})
        self.client.force_login(self.official.user)
        res = self.client.patch(url, {
            'name': 'updated school'
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        self.assertEqual('updated school', ret.get('name'))
        school.refresh_from_db()
        self.assertEqual('updated school', school.name)

    def test__retrieve(self):
        school = School.objects.order_by('?').first()
        url = reverse('school:for-official-detail', kwargs={'pk': school.id})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
