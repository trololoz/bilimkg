from common.tests.models import ModelTestCase
from common.tests.utils import create_staff
from school.models import School
from user.profile.models import Staff


class SchoolTest(ModelTestCase):
    def setUp(self):
        super().setUp()
        self.director = create_staff(self.school, self.user, role=Staff.ROLE_DIRECTOR)

    def test_director(self):
        self.assertEqual(self.school.director, self.director)
