from django.urls import reverse
from rest_framework import status

from school.models import School
from school.tests import BaseSchoolTestCase


class SchoolPupilTest(BaseSchoolTestCase):

    def setUp(self):
        super().setUp()

        self.pupil.school = School.objects.order_by('?').first()
        self.pupil.save()

    def test__list(self):
        url = reverse('school:for-pupil-list')
        self.client.force_login(self.pupil_user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN, res.json())

    def test__create(self):
        url = reverse('school:for-pupil-list')
        self.client.force_login(self.pupil_user)
        res = self.client.post(url, {
            'name': 'test school'
        })
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN, res.json())

    def test__update(self):
        url = reverse('school:for-pupil-detail', kwargs={'pk': self.pupil.school_id})
        self.client.force_login(self.pupil_user)
        res = self.client.post(url, {
            'name': 'updated school'
        })
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN, res.json())

    def test__retrieve(self):
        url = reverse('school:for-pupil-detail', kwargs={'pk': self.pupil.school_id})

        self.client.force_login(self.pupil_user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())

    def test__retrieve_forbidden(self):
        school = School.objects.exclude(pk=self.pupil.school_id).order_by('?').first()
        url = reverse('school:for-pupil-detail', kwargs={'pk': school.id})
        self.client.force_login(self.pupil_user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN, res.json())
