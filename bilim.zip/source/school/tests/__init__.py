from datetime import time
from random import choice

from django.urls import reverse
from rest_framework import status

from common.tests import CommonTestCase, create_course, create_pupil, create_teacher
from location.models import City, Region
from ministry.models import StudyYear
from school.administrative.models import CallSchedule, Classroom, Course, Housing, SchoolShift
from school.models import School
from user.profile.models import Staff


class BaseSchoolTestCase(CommonTestCase):
    pass


class BaseCourseTestCase(CommonTestCase):
    pass


class SchoolFilterTest(BaseSchoolTestCase):

    def setUp(self):
        super().setUp()

    def test__filter_name(self):
        url = reverse('school:for-official-list')
        self.client.force_login(self.official.user)

        q = 'Гимназия'
        cnt = School.objects.filter(name__icontains=q).count()

        res = self.client.get(url, {
            'name': q
        })

        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        self.assertEqual(cnt, len(ret))

    def test__filter_region(self):
        url = reverse('school:for-official-list')
        self.client.force_login(self.official.user)

        region = Region.objects.order_by('?').first()

        cnt = School.objects.filter(region=region).count()

        res = self.client.get(url, {
            'region': region.pk
        })

        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        self.assertEqual(cnt, len(ret))

    def test__filter_city(self):
        url = reverse('school:for-official-list')

        city = City.objects.order_by('?').first()

        cnt = School.objects.filter(city=city).count()

        self.client.force_login(self.official.user)
        res = self.client.get(url, {
            'city': city.pk
        })

        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()

        self.assertEqual(cnt, len(ret))


class SchoolCustomMethods(BaseSchoolTestCase):

    def test__housing(self):
        school = School.objects.order_by('?').first()
        Housing.objects.create(name='test housing', short_name='t.housing', school=school)

        url = reverse('school:for-official-housings', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(1, len(ret))
        self.assertEqual('test housing', ret[0].get('name'))

    def test__classroom(self):
        school = School.objects.order_by('?').first()
        Classroom.objects.create(school=school, floor=1, number=12, name='classroom name')
        url = reverse('school:for-official-classrooms', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(1, len(ret))
        self.assertEqual('classroom name', ret[0].get('name'))

    def test__course(self):
        school = School.objects.order_by('?').first()
        study_year = StudyYear.objects.get(current=True)
        teacher = create_teacher(school)
        Course.objects.create(study_year=study_year, school=school, parallel=1, index='a', form_master=teacher)
        url = reverse('school:for-official-courses', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(1, len(ret))
        self.assertEqual(1, ret[0].get('parallel'))
        self.assertEqual('a', ret[0].get('index'))

    def test__staff(self):
        school = School.objects.order_by('?').first()

        for i in range(3):
            create_teacher(school, role=choice([_role[0] for _role in Staff.ROLES]))

        url = reverse('school:for-official-staffs', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        for r in ret:
            self.assertEqual(school.pk, r.get('school'))

    def test__shift(self):
        school = School.objects.order_by('?').first()
        SchoolShift.objects.create(school=school, name='test shift')
        url = reverse('school:for-official-shifts', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual('test shift', ret[0].get('name'))

    def test__schedule(self):
        school = School.objects.order_by('?').first()
        shift = SchoolShift.objects.create(school=school, name='test shift')
        CallSchedule.objects.create(school=school, shift=shift, index=1, from_time=time(hour=8, minute=0),
                                    till_time=time(hour=8, minute=45))
        url = reverse('school:for-official-calls-schedule', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(1, ret[0].get('index'))

    def test__pupil(self):
        school = School.objects.order_by('?').first()

        p1, p2, p3 = [create_pupil(school=school, course=create_course(school), ) for _ in range(3)]
        url = reverse('school:for-official-pupils', kwargs={'pk': school.pk})
        self.client.force_login(self.official.user)
        res = self.client.get(url)
        self.assertEqual(res.status_code, status.HTTP_200_OK, res.json())
        ret = res.json()
        self.assertEqual(3, len(ret))

        for r in ret:
            self.assertEqual(school.pk, r.get('school'))
