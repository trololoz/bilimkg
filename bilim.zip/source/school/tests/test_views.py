from datetime import time
from common.tests.views import ViewSetTestCase
from common.tests.utils import create_pupil
from school.views.school import BaseSchoolViewSet, PupilSchoolViewSet
from school.administrative.models import Housing, Classroom, Course, SchoolShift, CallSchedule
from user.profile.models import Staff, Pupil


class BaseSchoolViewSetTest(ViewSetTestCase):
    view_class = BaseSchoolViewSet

    def setUp(self):
        super().setUp()
        self.view_kwargs['kwargs'] = {'pk': self.school.pk}
        housing = Housing.objects.create(school=self.school, name="Test Name", short_name="Name")
        Classroom.objects.create(housing=housing, school=self.school, floor=2, number=1, name="Test Name")
        shift = SchoolShift.objects.create(school=self.school, name="Test Name")
        callschedule = CallSchedule.objects.create(school=self.school, shift=shift, index=1, from_time=time(11, 0),
                                                   till_time=time(12, 30))
        create_pupil(school=self.school)

    def test_list_school_housings(self):
        response = self.view.list_school_housings(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), Housing.objects.filter(school=self.school).count())

    def test_list_school_classrooms(self):
        response = self.view.list_school_classrooms(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), Classroom.objects.filter(school=self.school).count())

    def test_list_school_courses(self):
        response = self.view.list_school_courses(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), Course.objects.filter(school=self.school).count())

    def test_list_school_staffs(self):
        response = self.view.list_school_staffs(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), Staff.objects.filter(school=self.school).count())

    def test_list_school_pupils(self):
        response = self.view.list_school_pupils(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), Pupil.objects.filter(school=self.school).count())

    def test_list_school_shifts(self):
        response = self.view.list_school_shifts(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), SchoolShift.objects.filter(school=self.school).count())

    def test_list_school_calls_schedule(self):
        response = self.view.list_school_calls_schedule(self.request)
        self.assertResponseIsOk(response)
        self.assertEqual(len(response.data), CallSchedule.objects.filter(school=self.school).count())


class PupilSchoolViewSetTest(ViewSetTestCase):
    view_class = PupilSchoolViewSet

    def test_has_object_permission(self):
        self.assertFalse(self.view.has_object_permission(self.request, self.school))
        self.request.user.roles_data = {
            'pupil': [{
                'school': self.school.pk
            }]
        }
        self.assertTrue(self.view.has_object_permission(self.request, self.school))
